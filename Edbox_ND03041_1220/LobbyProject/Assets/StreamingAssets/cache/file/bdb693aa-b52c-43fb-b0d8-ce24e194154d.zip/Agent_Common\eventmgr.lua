module("EventMgr", package.seeall )

local eventMgr = nil

function EventMgr:Instance()
	if nil == eventMgr then
		eventMgr = self
		eventMgr.listenerList = {}
	end
	return eventMgr
end

function EventMgr:AddEventListener(eventType,key,callBack,selfObj)
	assert(eventType ~= nil)
	assert(key ~= nil)
	assert(callBack ~= nil)

	if self.listenerList[eventType] == nil then
		self.listenerList[eventType] = {}
	end

	if self.listenerList[eventType][key] == nil then
		self.listenerList[eventType][key] = {}
	end

	local listenerData = {}
	listenerData.key = key
	listenerData.callBack = callBack
	listenerData.selfObj = selfObj

	self.listenerList[eventType][key] = listenerData
end

function EventMgr:RemoveEventListener(eventType,key)
	assert(eventType ~= nil)
	assert(key ~= nil)
	local list = self.listenerList[eventType]
	if list then
		list[key] = nil
		if LuaTable.IsEmpty(list) then
			self.listenerList[eventType] = nil
		end
	end
end

function EventMgr:removeAllEventListeners(key)
	assert(key ~= nil)
	for eventType,list in pairs(self.listenerList) do
		list[key] = nil
		if LuaTable.IsEmpty(list) then
			self.listenerList[eventType] = nil
		end
	end
end

function EventMgr:DispatchEvent(eventType,data)
	assert(eventType ~= nil)

	local list = self.listenerList[eventType]
	if list then
		for k,listenerData in pairs(list) do
			if listenerData.selfObj then
				listenerData.callBack(listenerData.selfObj,eventType,data)
			else
				listenerData.callBack(eventType, data)
			end
		end
	end
end
