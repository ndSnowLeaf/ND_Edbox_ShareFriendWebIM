local nextEventID = 0

local DefineEvent = function ()
	nextEventID = nextEventID + 1
	return nextEventID
end

--hero
EVENT_HERO_MOVESPEED_CHG						= DefineEvent()		--主角移动速度改变
EVENT_HERO_POS_CHG								= DefineEvent()		--主角位置改变
EVENT_HERO_ENTER_BATTLE							= DefineEvent()		--主角进入战斗状态
EVENT_HERO_LEAVE_BATTLE							= DefineEvent()		--主角离开战斗状态

--player

--monster

--npc