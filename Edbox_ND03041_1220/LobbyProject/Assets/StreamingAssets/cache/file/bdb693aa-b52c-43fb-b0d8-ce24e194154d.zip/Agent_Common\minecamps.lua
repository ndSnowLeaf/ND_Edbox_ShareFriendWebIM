local MineGenerater = require("MineGenerater");
local mineConfig = require("mineconfig")
require("common");


-- MineCamps class
--默认一个格子长度是1以下是多大区域进行打包
MineCamps = {
    nInitMaxW = 0,
    nInitMaxL = 0,
    nInitMaxH = 0,
    nCurTimeCount = 0,
    mineMap = {},
    mineGenerater = {},
    mData = {}
}

--传入参数对象包含了格子规格大小 ,入口至大小需要是格子大小倍数
function MineCamps:new (obj)
    obj = obj or {};
    setmetatable(obj, self);
    self.__index = self
    self.nInitMaxW = 10; -- obj.nInitMaxW or 10;
    self.nInitMaxL = 10; --obj.nInitMaxL or 10;
    self.nInitMaxH = 10; --obj.nInitMaxH or 10;
    self.oMineMap = obj.oMineMap or {};--MineCell
    self.nCurTimeCount = 0;
    self.mineGenerater = MineGenerater:Instance();
    self.mData = MineData:New()
    --print(self.nInitMaxW);
    MineCamps:create ();
    print("MineCamps ========================================================  MineCamps");
    return obj
end
--单例
function MineCamps:Instance(param)
	if MineCamps.instance == nil then
		MineCamps.instance = MineCamps:new(param)
    end
    
	return MineCamps.instance
end

--第一次创建一层 create
function MineCamps:create ()
	MineCamps.oMineMap = {}
    --print('create', MineCamps.nInitMaxW, MineCamps.nInitMaxL);
    local mineArr = MineCamps.mineGenerater:genFloorCells(-1, MineCamps.nInitMaxW*MineCamps.nInitMaxL);
    --printTable(mineArr)
    local i= 1;
    local j= 1;

    for i= 1, MineCamps.nInitMaxW do
         for j= 1, MineCamps.nInitMaxL do        
            key =  MineCamps:getKeyByPos({i, -1, j})
            --MineCamps.oMineMap[key] = MineCell:New();
            --printTable({i, j, 1})
           -- print(i, j, MineCamps.nInitMaxW, ((i-1)*MineCamps.nInitMaxW+j));
           -- MineCamps.oMineMap[key]:setData(mineArr[(i-1)*MineCamps.nInitMaxW+j], {i, -1, j});            
          --  print('  create   ', mineArr[(i-1)*MineCamps.nInitMaxW+j][1] , mineArr[(i-1)*MineCamps.nInitMaxW+j][2]);--print

          MineCamps.oMineMap[key] = {x=i, y=-1, z=j, nTypeId= mineArr[(i-1)*MineCamps.nInitMaxW+j][1], nLife= mineArr[(i-1)*MineCamps.nInitMaxW+j][2], nType= mineArr[(i-1)*MineCamps.nInitMaxW+j][3]}
          end
    end
    
    self.mData:setData({}, MineCamps.oMineMap, {})
  --  printTable(MineCamps.oMineMap);
end


function MineCamps:removeMineData(pos)    
    --zct MineCamps.oMineMap[MineCamps:getKeyByPos(pos)]:Destroy();
    local res = {}--{"nTypeId":0, "nLife":0};    
    res.nTypeId = MineCamps.oMineMap[MineCamps:getKeyByPos(pos)].nTypeId;
    res.nLife = MineCamps.oMineMap[MineCamps:getKeyByPos(pos)].nLife;
    res.nType = MineCamps.oMineMap[MineCamps:getKeyByPos(pos)].nType;
    res.x = MineCamps.oMineMap[MineCamps:getKeyByPos(pos)].x;
    res.y = MineCamps.oMineMap[MineCamps:getKeyByPos(pos)].y;
    res.z = MineCamps.oMineMap[MineCamps:getKeyByPos(pos)].z;
    MineCamps.oMineMap[MineCamps:getKeyByPos(pos)].nLife = -1;
    --MineCamps.oMineMap[MineCamps:getKeyByPos(pos)]:Destroy();--调用会报错
    
    return res;
end

--挖完矿移除单个格子
function MineCamps:removeCell(pos)
    if MineCamps:checkMine(pos)  ~= 1 then
        print("not found mine of key:", key);
        return {};
    end

    local genParam = MineCamps:genCreateCellParam(pos);
        
    local addRes = MineCamps:createCell(genParam);
    local removeRes = MineCamps:removeMineData(pos);     
   -- mData = MineData:New()
    self.mData:setData({data=removeRes}, addRes, {})
    return removeRes;
end

--挖完矿移除多个格子 removeCells
function MineCamps:removeCells(posArr)
    local nPosLen = table.getn(posArr);    --检查参数
    if nPosLen<1 then
        print("removeCells posArr len value error:");
        return {};
    end

    local resArr = {}
    for i=1, nPosLen do --检查是否存在矿 是否要返回
        if MineCamps:checkMine(posArr[i]) ~= 1 then
            print("not found mine of key:", key);            
            --return; 
        else --这个做法要解决重复数据
        --    MineCamps:removeMineData(posArr[i]);
        --    MineCamps:createCell(posArr[i]);
        
        --printTable(MineCamps:removeMineData(posArr[i]))
            table.insert(resArr, MineCamps:removeMineData(posArr[i]));
        end
    end
      
    local genParam = MineCamps:genCreateCellsParam(posArr);
    MineCamps:createCell(genParam);
    return resArr;
end


function MineCamps:genPosNearCell(pos)
    if (pos[2] < -MineCamps.nInitMaxH-1) then --指定层数以下的无限制
        local tmpCellArr = {{(pos[1]+1), pos[2] , pos[3] },      
            {pos[1] - 1, pos[2] , pos[3] },
            {pos[1] , pos[2] + 1, pos[3] },
            {pos[1] , pos[2] - 1, pos[3] },
            {pos[1] , pos[2] , pos[3] + 1},
            {pos[1] , pos[2] , pos[3] - 1}};
        return tmpCellArr;
    elseif pos[2] >= 0 then --参数0层或以上直接返回空
        return {};
    elseif pos[2]  == -MineCamps.nInitMaxH-1 then--参数在固定控制格子
        local tmpCellArr = {{(pos[1]+1), pos[2] , pos[3] },      
            {pos[1] - 1, pos[2] , pos[3] },
            {pos[1] , pos[2] - 1, pos[3] },
            {pos[1] , pos[2], pos[3] - 1 },
            {pos[1] , pos[2] , pos[3] + 1}};
        return tmpCellArr;
    elseif pos[2] > -MineCamps.nInitMaxH-1 then--参数在固定控制格子
        local tmpCellArr = {{pos[1] , pos[2] - 1 , pos[3]}};
        if pos[1] > 1 then
            table.insert(tmpCellArr, table.getn(tmpCellArr)+1, {pos[1] - 1, pos[2] , pos[3] });
        end
        if pos[1] < MineCamps.nInitMaxW then
            table.insert(tmpCellArr, table.getn(tmpCellArr)+1, {pos[1]+1, pos[2] , pos[3] });
        end
        if pos[3] > 1 then
            table.insert(tmpCellArr, table.getn(tmpCellArr)+1, {pos[1] , pos[2], pos[3]  - 1});
        end
        if pos[3] < MineCamps.nInitMaxL then
            table.insert(tmpCellArr, table.getn(tmpCellArr)+1, {pos[1] , pos[2], pos[3]  + 1});
        end
        if pos[2] < -1 then
            table.insert(tmpCellArr, table.getn(tmpCellArr)+1, {pos[1] , pos[2] + 1 , pos[3]});
        end
        return tmpCellArr;
    else
        return {};
    end
end

function MineCamps:genCreateCellsParam(posArr)
    local nPosLen = table.getn(posArr);    
    if nPosLen == 1 then    --检查参数    
        return MineCamps:genCreateCellParam(posArr[1]);
    else         
        local resArr={}
        for i=1, nPosLen do 
            local pos = posArr[i];
            local vecArr = MineCamps:genPosNearCell(pos);
            local cellLen = table.getn(vecArr);
            for j=1, cellLen do 
                local key = MineCamps:getKeyByPos(vecArr[i]);
                if MineCamps:checkMine(vecArr[j]) == 0 then
                    resArr[key] = vecArr[i];
                else
                    --已生成或已存在
                end
            end
        end
        return resArr;
    end
end

function MineCamps:genCreateCellParam(pos)
    local vecArr = MineCamps:genPosNearCell(pos);
    --printTable(vecArr); 
    local resArr = {};
    local cellLen = table.getn(vecArr);
    for i=1, cellLen do 
        if MineCamps:checkMine(vecArr[i])  == 0 then
            local key = MineCamps:getKeyByPos(vecArr[i]);
            resArr[key] = vecArr[i];
        else --已存在 已挖
        end
    end
    return resArr;
end

--挖更新突然石头信息 updateCell  补充
function MineCamps:updateCell(pos, val)
    if MineCamps:checkMine(pos)  ~= 1 then
        print("not found mine of");
        return;
    end    
    if val < 1 then
        print("updateCell data param error val:", val);
        return;
    end 

    local res = {}
    local key = MineCamps:getKeyByPos(pos);
   -- printTable(MineCamps.oMineMap);    
    res.nTypeId = MineCamps.oMineMap[key].nTypeId;
    res.nLife = MineCamps.oMineMap[key].nLife - val;
    MineCamps.oMineMap[key].nLife = val;
	res.x=pos[1]
	res.y=pos[2]
	res.z=pos[3]
	--printTable(res);
    self.mData:setData({}, {}, {nTypeId=MineCamps.oMineMap[key].nTypeId, nLife=MineCamps.oMineMap[key].nLife, x=pos[1],y=pos[2],z=pos[3]})
    return res;
  --  printTable(MineCamps.oMineMap);    
  --  print("updateCell: mine map data flush!");
    --printTable(MineCamps.oMineMap[key]);   
end

--校验当前是否存在 存在0标识未生成  1表示已存在  2 表示已挖过
function MineCamps:checkMine(pos)
    local key = MineCamps:getKeyByPos(pos);
    if MineCamps.oMineMap[key] == nil then
        return 0;
    elseif MineCamps.oMineMap[key].nLife == -1 then
        return 2;
    else
        return 1;
    end
end



function MineCamps:getKeyByPos(pos)
    return tostring(pos[1])..','..tostring(pos[2])..','..tostring(pos[3]);
end

function MineCamps:genEmptyCell(pos)
    local genParam = MineCamps:genCreateCellParam(pos);
    return MineCamps:createCell(genParam);
end

--创建挖掉需要创建格子 createCell
function MineCamps:createCell (genParams)
    local arrFloor = {};--层级数组
    local arrNum = {};--层级生成个数数组
    local arrFloorTmp = {};--层级去重后map对象
    local arrNumTmp = {};--层级数量统计
    local arrKeyGen = {};--每个层级与key数组

   --printTable(genParams);
   --生成层级  层级需要生成个数 层级主键列表
    for key, value in pairs(genParams) do        
        arrFloorTmp[value[2]] =  key;
        arrNumTmp[value[2]] = arrNumTmp[value[2] ] or 0;
        arrNumTmp[value[2]] = arrNumTmp[value[2]] + 1;
        arrKeyGen[value[2]] = arrKeyGen[value[2]] or {};
        local keyTag = table.getn(arrKeyGen[value[2]]) + 1;
        table.insert(arrKeyGen[value[2]], keyTag, key);
    end

    --生成格子需要的入参
   local tag = 1;
    for key, value in pairs(arrFloorTmp) do
        table.insert(arrFloor,tag,key);
        table.insert(arrNum,tag,arrNumTmp[key]);
        tag = tag + 1;
    end
    
    --批量生成格子数据
    --printTable(arrFloor)
    --printTable(arrNum)
    local genMineArr = MineCamps.mineGenerater:genCells(arrFloor, arrNum);
    --printTable(genMineArr)
    local nMineLen = table.getn(genMineArr);
   -- printTable(arrKeyGen);
    --printTable(genParams);
    local addRes = {}
    for i=1, nMineLen do
        local nMineSubLen = table.getn(genMineArr[i]);
        local keyArr = arrKeyGen[arrFloor[i]];
        local nKeyArrLen = table.getn(keyArr);
        if nKeyArrLen ~= nMineSubLen then
            print('gen data error !!!!!!!!!!!!!!!!!!!!!');
            printTable(genMineArr[i])
            printTable(keyArr)
            
        end
        for j=1, nKeyArrLen do
            MineCamps.oMineMap[keyArr[j]] = {nTypeId=genMineArr[i][j][1], nLife=genMineArr[i][j][2], nType=genMineArr[i][j][3], x=genParams[keyArr[j]][1], y=genParams[keyArr[j]][2], z=genParams[keyArr[j]][3]}
           
            addRes[keyArr[j]] = {nTypeId=genMineArr[i][j][1], nLife=genMineArr[i][j][2], nType=genMineArr[i][j][3], x=genParams[keyArr[j]][1], y=genParams[keyArr[j]][2], z=genParams[keyArr[j]][3]}
            -- MineCamps.oMineMap[keyArr[j]] = MineCell:New();
          --  MineCamps.oMineMap[keyArr[j]]:setData(genMineArr[i][j], genParams[keyArr[j]]);
            if addRes[keyArr[j]].nTypeId == 1000200000701 or addRes[keyArr[j]].nType == 2 then
                --print("1111111111111111111111111111111111111111111111111", addRes[keyArr[j]].nTypeId)
                local resData = MineCamps:genEmptyCell(genParams[keyArr[j]])
                --printTable(resData)
                for  key, value in pairs(resData) do 
                   -- print("22222222222222222222222222222222222222222222222222222222222222222", key)
                    addRes[key] = {nTypeId=value.nTypeId, nLife=value.nLife, nType=value.nType, x=value.x, y=value.y, z=value.z}
                end 
            end
            --printTable(genParams[keyArr[j]]);
            --printTable(genMineArr[i][j]);
        end
    end
    --返回给客户端数据
    --printTable(addRes);
    return addRes--返回值暂定跟服务端一致
end

--获取全部矿数据
function MineCamps:getAllMine()
    --printTable(MineCamps.oMineMap);
    return MineCamps.oMineMap;
end

--获取矿数据
function MineCamps:getMineCell(pos)
    if MineCamps:checkMine(pos) ~= 1 then
        print("not found mine of");
        return;
    end
    local key = MineCamps:getKeyByPos(pos);
    return MineCamps.oMineMap[key];
end

--挖矿一个
function MineCamps:mineral(pos, attack)

    printTable(pos);
    if MineCamps:checkMine(pos) ~= 1 then
        print("not found mine of");
        return {};
    end
    local key = MineCamps:getKeyByPos(pos);
    if MineCamps.oMineMap[key].nLife > attack then        
        return MineCamps:updateCell(pos, MineCamps.oMineMap[key].nLife - attack)
    else         
        return MineCamps:removeCell(pos)
    end
end

--挖矿多个
function MineCamps:minerals(posArr, attack)
    local nPosLen = table.getn(posArr);
    local removeArr = {} --先统计全部移除的移除的矿
    local resArr = {}
    
    for j=1, nPosLen do
        --printTable (posArr[j])
        if MineCamps:checkMine(posArr[j])  ~= 1 then
            print("not found mine of");
            --return{};
        else           
            local key = MineCamps:getKeyByPos(posArr[j]);            
            if MineCamps.oMineMap[key].nLife > attack then
                table.insert(resArr, MineCamps:updateCell(posArr[j], MineCamps.oMineMap[key].nLife - attack))
            else                
                table.insert(removeArr, posArr[j]);
            end
        end
     end
     --printTable(posArr);
     local removeDatas = MineCamps:removeCells(removeArr);
     --printTable(removeDatas);
    
    for k,v in pairs(removeDatas) do
        table.insert(resArr, v)
    end
    --printTable(resArr);
    return resArr;
end

--重置矿区
function MineCamps:reset()
    MineCamps:destroy()
    MineCamps:create();    
end

--销毁当前矿区
function MineCamps:destroy()
--[[    local nMineLen = table.getn(MineCamps.oMineMap);
    for k,v in pairs(MineCamps.oMineMap) do
        if v ~= false and v ~= nil then
           -- print("-----------------------------------------------------------------------updateCamps", k);
            v:Destroy()           
        end     
        MineCamps.oMineMap[k] = nil   
    end
--]]
   -- print("-------------------------------------------------------------------sssssssssssss----updateCamps");
    --mData = MineData:New(); 
    --self.mData:setData(MineCamps.oMineMap, {}, {})
    MineCamps.mineMap = {};    
end

--销毁当前矿区
function MineCamps:updateCamps(deltaTime)
    MineCamps.nCurTimeCount  = MineCamps.nCurTimeCount+deltaTime;
    if MineCamps.nCurTimeCount > mineConfig.refreshTime then
        MineCamps.nCurTimeCount = 0;
        print("-----------------------------------------------------------------------updateCamps", MineCamps.nCurTimeCount);
        return true
    end    
    return false
end

return MineCamps;