require("common")
require("const")
local ItemType = require ("itemType")
local json = require ("dkjson")
local CONFIG = require("config")
local host = CONFIG.MMO_HTTP_SERVER_HOST
local port = CONFIG.MMO_HTTP_SERVER_PORT

Equipment = {
    equipmentSet = {},
    equipments = {},
    owner = {}
}

Equipment.__index = Equipment

function Equipment:new (owner)
    newEquipment = {}
    setmetatable(newEquipment, Equipment)
    newEquipment.equipmentSet = {}
    newEquipment.equipments = {}
    newEquipment.owner = owner
    return newEquipment
end

function Equipment:setData(item)
    local setItem = {}
    setItem.itemTypeId = item.id or Const.ZERO;
    setItem.typeId = item.typeId or Const.ZERO;
    setItem.equip = item.equip or false;
    setItem.activation = item.activation or false;
    setItem.addition = Const.ZERO; -- 装备加成，暂时设置成0
    return setItem
end

-- 初始化
function Equipment:initEquipment()   
    local storeKey =  self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".equipment" 
    local sendData = {}
    sendData.storeKey = storeKey
    sendData.apiName = "get"
    sendData = json.encode(sendData)
    self.owner.DataStore:DataStoreOperation(host, port, sendData, "getEquipmentRes")
end

function Equipment:getEquipmentRes(list) 
    local list = json.decode(list)
    local data = list.data
    local equipmentData = {}

    if(type(data.value) == "string")then
        equipmentData = json.decode(data.value)
        if(type(equipmentData) ~= "table")then
            equipmentData = {}
        end
    end

    if(equipmentData == nil or (type(equipmentData) == "table" and (next(equipmentData) == nil)))then
        equipmentData = {}
        local equipment= self:setData(ItemType[Const.INITIAL_EQUIPMENT])
        equipment.equip = true
        equipment.activation = false
        -- table.insert(equipmentData, equipment.itemTypeId, equipment)
        equipmentData[equipment.itemTypeId] = equipment
    end
    if(type(self.equipments) == "table" and next(self.equipments) ~= nil) then
        print("equipments must be empty first ---------------<equipments>" .. self.owner:getPlayerId())
    end

    for i, equipment in pairs(equipmentData)
        do
        if(ItemType[equipment.itemTypeId].type == Const.EQUIPMENT_TYPE ) then
            if(equipment.equip == true ) then
                local tag = Const.ONE -- 装备位置，需要扩展
                local action = Const.ZERO
                equipment.activation = false

                self.equipmentSet[tag] = equipment
                self.owner:useEquip(action, equipment.itemTypeId)
            end
            -- table.insert(self.equipments, equipment.itemTypeId, equipment)
            self.equipments[equipment.itemTypeId] = equipment
        end
    end
end

-- 获取制定位置装备
function Equipment:getEquipByTag(tag)
    if(self.equipmentSet ~= nil or (type(self.equipmentSet) == "table" and (next(self.equipmentSet) == nil)) )then
        return deepCopy(self.equipmentSet[tag])
    else
        return false
    end
end

--[[
--设置装备CD
function Equipment:setEquipeCD(equipeTypeId, nextUseTime)
    if(self.equipmentSet[equipeTypeId] ~= nil)then
        self.equipmentSet[equipeTypeId].nextUseTime = nextUseTime
    else
        return false
    end
end
]]

-- 获取有的装备
function Equipment:getEquipment()
    local equipments = deepCopy(self.equipments)
    return json.encode(equipments)
end  

-- 获取已装备
function Equipment:getEquipmentSet()
    return deepCopy(self.equipmentSet)
end   

-- add装备
function Equipment:addEquipment(playerId, equipmentId)
    if(playerId == self.owner:getPlayerId()) then
        if(self.equipments[equipmentId] == nil) then
            local tag = Const.ONE
            if(self.equipmentSet[tag] ~= nil) then
                local old = deepCopy(self.equipmentSet[tag])
                old.equip = false
                old.activation = false
                self.equipments[old.itemTypeId] = nil
                self.equipments[old.itemTypeId] = old
            end
            self.equipmentSet[tag] = nil

            local equipment = self:setData(ItemType[equipmentId])
            equipment.equip = true
            equipment.activation = true

            self.equipmentSet[tag] = equipment
            -- add
            self.equipments[equipment.itemTypeId] = equipment
            
            -- table.insert(self.equipments, equipment.itemTypeId, equipment)
            local sendData = {}
            local storeKey = self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".equipment" 
            sendData.storeKey = storeKey
            sendData.value = json.encode(deepCopy(self.equipments))
            sendData.apiName = "set"
            sendData = json.encode(sendData)
            self.owner.DataStore:DataStoreOperation(host, port, sendData, "addEquipRes")        
        else
            print("have no playerId or equipmentId")
            return false
        end 
    else
        print("addEquipment>>>>>>>>>>>>>>>>>>>>>>>>>>>>.............playerId ERROR!!!")
        return false
    end
end

-- add装备响应
function Equipment:addEquipRes(list)
    local list = json.decode(list)
    local data = list.data
    local tag = Const.ONE -- 后面版本itemType配置
    local action = Const.ONE -- 枚举数据
    local equipment = deepCopy(self.equipmentSet[tag])
    self.owner:useEquip(action, equipment.itemTypeId)
    self.owner:GetAllEquipServer()
end

-- 交换装备
function Equipment:changeEquip(playerId, newEquipmentId)
    if(playerId == self.owner:getPlayerId()) then
        local tag = Const.ONE -- 后面版本itemType配置
        if(self.equipments[newEquipmentId] ~= nil and newEquipmentId ~= self.equipmentSet[tag].itemTypeId) then
            local equipment = deepCopy(self.equipmentSet[tag])
            equipment.equip = false
            equipment.activation = false
            self.equipments[equipment.itemTypeId] = nil
            self.equipments[equipment.itemTypeId] = equipment

            local newEquipment= self:setData(ItemType[newEquipmentId])
            newEquipment.equip = true
            newEquipment.activation = true
            self.equipments[newEquipmentId] = nil
            self.equipments[newEquipmentId] = newEquipment

            self.equipmentSet[tag] = deepCopy(self.equipments[newEquipmentId])
            local storeKey = self.owner.nGameId .. "."  .. self.owner:getPlayerId() .. ".equipment" 
            local sendData = {}
            sendData.storeKey = storeKey
            sendData.value = json.encode(deepCopy(self.equipments))
            sendData.apiName = "set"
            sendData = json.encode(sendData)
            self.owner.DataStore:DataStoreOperation(host, port, sendData, "chgNewEquipRes")  
            return true
        else 
            print("changeEquip>>>>>>>>>>>>>>>>>>>>>>>>>>>>.............playerId ERROR!!!")
            return false
        end
    else

    end 

end

function Equipment:chgNewEquipRes(list)
    local list = json.decode(list)
    local data = list.data
    local tag = Const.ONE -- 后面版本itemType配置
    local action = Const.ONE -- 枚举数据
    local equipment = deepCopy(self.equipmentSet[tag])
    self.owner:useEquip(action, equipment.itemTypeId)
    self.owner:GetAllEquipServer()
end

-- 穿脱装备
function Equipment:activeEuipment(itemTypeId, tag)
    if(tag ~= nil) then
        local equipment = deepCopy(self.equipmentSet[tag])
        if(itemTypeId == equipment.itemTypeId) then
            local action = 1
            if(equipment.equip == true)then
                if(equipment.activation == true) then
                    equipment.activation = false
                    action = 0
                else
                    equipment.activation = true
                end
                self.equipmentSet[tag] = nil
                self.equipmentSet[tag] = equipment
                self.equipments[equipment.itemTypeId] = nil
                self.equipments[equipment.itemTypeId] = equipment

                local sendData = {}  
                sendData.storeKey = self.owner.nGameId .. "." .. self.owner.playerId .. ".equipment" 
                sendData.value = json.encode(deepCopy(self.equipments))
                sendData.apiName = "set"
                sendData.action = action
                sendData.tag = tag
                sendData = json.encode(sendData)
                self.owner.DataStore:DataStoreOperation(host, port, sendData, "activeEuipRes") 
                return true
            else 
                return false 
            end
        else
            return false
        end
    else
        print("have no args")
        return false
    end
end

function Equipment:activeEuipRes(list)
    local list = json.decode(list)
    local data = list.data
    local tag = data.tag -- 后面版本itemType配置
    local equipment = deepCopy(self.equipmentSet[tag])
    self.owner:useEquip(data.action, equipment.itemTypeId)
end

return Equipment