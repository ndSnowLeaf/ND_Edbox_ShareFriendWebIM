local mineType = require("minetype")
local itemType = require("itemtype")
local os        = require "os"
require("common");
--local MineCell = require("mineCell")

-- MineGenerater class
--格子生成者
MineGenerater = {
    oMineTypeArr = {};
    nRateLen = 100;
    nMaxFloor = 0;
}

--传入参数对象包含了格子规格大小 ,入口至大小需要是格子大小倍数
function MineGenerater:new (obj)
  obj = obj or {};
  setmetatable(obj, self);
  --===============================================================server===============================================================
  self.__index = self
  self.nRateLen = obj.nRateLen or 100;
  self.nMaxFloor = -1;
  self.oMineTypeArr = obj.oMineTypeArr or {};
  --===============================================================server end===============================================================
  self.loadMineType();
  return obj
end

--===============================================================server===============================================================
--单例
function MineGenerater:Instance()
	if MineGenerater.instance == nil then
		MineGenerater.instance = MineGenerater:new()
    end
    
	return MineGenerater.instance
end

--加载全部层数可能包含类型矿
function MineGenerater:loadMineType ()
    local nTypeLen = table.getn(mineType);    --全部层级
    if nTypeLen<1 then
        print("mine type data error");
        return;
    end

    for i= 1, nTypeLen do
        MineGenerater.oMineTypeArr[i] = {};
        local mineTypeArr = mineType[i];--一层可能存在矿情况
        local nMineLen = table.getn(mineTypeArr);
        if nMineLen<1 then
            print("mine type data error");
            return;
        end
        local nTag = 1;
        local nVal = mineTypeArr[1].rate;
        for j= 1, MineGenerater.nRateLen do
             if j > nVal then
                nTag = 1 + nTag;
                nVal = nVal + mineTypeArr[nTag].rate;
             end
                MineGenerater.oMineTypeArr[i][j] = {mineTypeArr[nTag].itemtype, itemType[mineTypeArr[nTag].itemtype].weight,  mineTypeArr[nTag].type};
            -- print(MineGenerater.oMineTypeArr[i][j][1], MineGenerater.oMineTypeArr[i][j][2]);--print
        end
    end
    MineGenerater.nMaxFloor = -nTypeLen;
end

--生成一个矿
function MineGenerater:genOneCell (nFloor)
    --local obj = MineCell:New();--obj = MineCell:New();
    --obj:setData();
    if nFloor < MineGenerater.nMaxFloor then 
        nFloor = MineGenerater.nMaxFloor
    end
    return MineGenerater.oMineTypeArr[nFloor][math.random(1, MineGenerater.nRateLen)];
end

--n层生成arrNum数组个矿
function MineGenerater:genCells (arrFloor, arrNum)
    local nFloorLen = table.getn(arrFloor);
    if (nFloorLen < 1) or (nFloorLen ~= table.getn(arrNum)) then
        print(' gen date len error! ');
        return {};
    end
    local arrResT = {};
    for i= 1, nFloorLen do
        nFloor =  arrFloor[i]
        if nFloor < MineGenerater.nMaxFloor then 
            nFloor = MineGenerater.nMaxFloor
        end
        arrResT[i] = MineGenerater:genFloorCells(nFloor, arrNum[i]);
    end    
    --printTable(arrResT);
    return arrResT;
end

--一层生成nNum个矿
function MineGenerater:genFloorCells (nFloor, nNum)
    --print(' MineGenerater:genFloorCells ', nFloor, nNum)
    if nNum<1 then
        print('nNum value error, :', nNum);
        return  {};
    end

    --if MineGenerater.oMineTypeArr[-nFloor] == nil then
     --   print('nFloor error, not found  oMineTypeArr:', nFloor);
     --   return  {};
    --end
    if nFloor < MineGenerater.nMaxFloor then 
        nFloor = MineGenerater.nMaxFloor
    end

    local arrRes = {};
    --printTable(MineCell);
    for i= 1, nNum do
        --table.insert(arrRes[i], i, MineGenerater.oMineTypeArr[nFloor][math.random(1, MineGenerater.nRateLen)]);
        arrRes[i] = MineGenerater.oMineTypeArr[-nFloor][math.random(1, MineGenerater.nRateLen)];--arrRes[i] = MineCell:New();
        --print(' MineGenerater:genFloorCells  res------ ', nFloor, MineGenerater.nRateLen, MineGenerater.oMineTypeArr[nFloor][math.random(1, MineGenerater.nRateLen)])
        
        --arrRes[i]:setData();
        
     --   arrRes[i] =  cellData;
        --arrRes[i] = MineCell:new(MineGenerater.oMineTypeArr[nFloor][math.random(1, MineGenerater.nRateLen)]);        
    end
    --printTable(arrRes);
    return arrRes;
end

--生成立方体
function MineGenerater:genSquare(nFloor, val)
    
end
--===============================================================server end===============================================================

--===============================================================client===============================================================
--local test = MineGenerater:new({})
return MineGenerater;