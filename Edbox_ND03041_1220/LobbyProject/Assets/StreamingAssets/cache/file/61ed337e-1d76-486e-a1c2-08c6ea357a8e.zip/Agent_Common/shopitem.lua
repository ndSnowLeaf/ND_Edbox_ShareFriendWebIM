DATA = {}
DATA[1]={id = 1,gameid="",shopId="1001",itemTypeId="2000100000001",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Wooden Pickaxe",price=0,ed_price=0}
DATA[2]={id = 2,gameid="",shopId="1001",itemTypeId="2000100000101",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Stone Pickaxe",price=25,ed_price=0}
DATA[3]={id = 3,gameid="",shopId="1001",itemTypeId="2000100000201",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Metal Pickaxe",price=75,ed_price=0}
DATA[4]={id = 4,gameid="",shopId="1001",itemTypeId="2000100000301",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Mattock",price=250,ed_price=0}
DATA[5]={id = 5,gameid="",shopId="1001",itemTypeId="2000100000401",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Shovel",price=600,ed_price=0}
DATA[6]={id = 6,gameid="",shopId="1001",itemTypeId="2000100000701",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Crowbar",price=2000,ed_price=0}
DATA[7]={id = 7,gameid="",shopId="1001",itemTypeId="2000100000501",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Spork",price=3500,ed_price=0}
DATA[8]={id = 8,gameid="",shopId="1001",itemTypeId="2000100000801",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Sledge Hammer",price=6000,ed_price=0}
DATA[9]={id = 9,gameid="",shopId="1001",itemTypeId="2000100000901",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Wrench",price=7000,ed_price=0}
DATA[10]={id = 10,gameid="",shopId="1001",itemTypeId="2000100000601",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Snow Shovel",price=9000,ed_price=0}
DATA[11]={id = 11,gameid="",shopId="1001",itemTypeId="2000110000001",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Lawn Mover",price=12000,ed_price=0}
DATA[12]={id = 12,gameid="",shopId="1001",itemTypeId="2000110000101",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Chainsaw",price=16500,ed_price=0}
DATA[13]={id = 13,gameid="",shopId="1001",itemTypeId="2000110000201",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Power Drill",price=32000,ed_price=0}
DATA[14]={id = 14,gameid="",shopId="1001",itemTypeId="2000110000301",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Large Drill",price=78000,ed_price=0}
DATA[15]={id = 15,gameid="",shopId="1001",itemTypeId="2000110000401",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Thin Drill",price=100000,ed_price=0}
DATA[16]={id = 16,gameid="",shopId="1001",itemTypeId="2000110000501",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Power Saw",price=120000,ed_price=0}
DATA[18]={id = 18,gameid="",shopId="1001",itemTypeId="2000120000101",res_id="db356e56-ac6b-4645-a307-54efc04131f4",name="C4",price=360000,ed_price=0}
DATA[21]={id = 21,gameid="",shopId="1001",itemTypeId="2000100001001",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Basher",price=400000,ed_price=0}
DATA[22]={id = 22,gameid="",shopId="1001",itemTypeId="2000110000601",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Long Drill",price=500000,ed_price=0}
DATA[23]={id = 23,gameid="",shopId="1001",itemTypeId="2000110000701",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Power Gun",price=550000,ed_price=0}
DATA[24]={id = 24,gameid="",shopId="1001",itemTypeId="2000110000801",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Jackhammer",price=610000,ed_price=0}
DATA[25]={id = 25,gameid="",shopId="1001",itemTypeId="2000110000901",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Flamethrower",price=775000,ed_price=0}
DATA[26]={id = 26,gameid="",shopId="1001",itemTypeId="2000110001001",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Laser Gun",price=1100000,ed_price=0}
DATA[27]={id = 27,gameid="",shopId="1001",itemTypeId="2000110001101",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Deathdrill",price=2000000,ed_price=0}
DATA[28]={id = 28,gameid="",shopId="1001",itemTypeId="2000100001101",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Golden Scissors",price=2450000,ed_price=0}
DATA[29]={id = 29,gameid="",shopId="1001",itemTypeId="2000100001201",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Bloxy",price=3500000,ed_price=0}
DATA[30]={id = 30,gameid="",shopId="1001",itemTypeId="2000100001301",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Zues's staff",price=5500000,ed_price=0}
DATA[32]={id = 32,gameid="",shopId="1001",itemTypeId="2000110001201",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Ray Gun",price=8000000,ed_price=0}
DATA[33]={id = 33,gameid="",shopId="1001",itemTypeId="2000110001301",res_id="9a0da3ec-5269-4cd8-b395-17825dec7c49",name="Ultra Ray Gun",price=15000000,ed_price=0}
DATA[35]={id = 35,gameid="",shopId="1002",itemTypeId="3000000000001",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Small Backpack",price=0,ed_price=0}
DATA[37]={id = 37,gameid="",shopId="1002",itemTypeId="3000000000201",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Backpack",price=45,ed_price=0}
DATA[38]={id = 38,gameid="",shopId="1002",itemTypeId="3000000000301",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Large Backpack",price=350,ed_price=0}
DATA[39]={id = 39,gameid="",shopId="1002",itemTypeId="3000000000401",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Potatosack",price=1200,ed_price=0}
DATA[40]={id = 40,gameid="",shopId="1002",itemTypeId="3000000000501",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Milltray Pack",price=3500,ed_price=0}
DATA[41]={id = 41,gameid="",shopId="1002",itemTypeId="3000000000601",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Ruck Sack",price=5000,ed_price=0}
DATA[42]={id = 42,gameid="",shopId="1002",itemTypeId="3000000000701",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Suitcase",price=7500,ed_price=0}
DATA[43]={id = 43,gameid="",shopId="1002",itemTypeId="3000000000801",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Duffel Bag",price=15000,ed_price=0}
DATA[44]={id = 44,gameid="",shopId="1002",itemTypeId="3000000000901",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Travel Pack",price=25000,ed_price=0}
DATA[45]={id = 45,gameid="",shopId="1002",itemTypeId="3000000001001",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Small Canister",price=35000,ed_price=0}
DATA[46]={id = 46,gameid="",shopId="1002",itemTypeId="3000000001101",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Medium Canister",price=72000,ed_price=0}
DATA[47]={id = 47,gameid="",shopId="1002",itemTypeId="3000000001201",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Large Canister",price=150000,ed_price=0}
DATA[48]={id = 48,gameid="",shopId="1002",itemTypeId="3000000001301",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Cylinder Pack",price=200000,ed_price=0}
DATA[49]={id = 49,gameid="",shopId="1002",itemTypeId="3000000001401",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Wooden Bucket",price=260000,ed_price=0}
DATA[50]={id = 50,gameid="",shopId="1002",itemTypeId="3000000001501",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Small Barrel",price=300000,ed_price=0}
DATA[51]={id = 51,gameid="",shopId="1002",itemTypeId="3000000001601",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Mideum Barrel",price=375000,ed_price=0}
DATA[52]={id = 52,gameid="",shopId="1002",itemTypeId="3000000001701",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Large Barrel",price=450000,ed_price=0}
DATA[53]={id = 53,gameid="",shopId="1002",itemTypeId="3000000001801",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Small Vault",price=700000,ed_price=0}
DATA[54]={id = 54,gameid="",shopId="1002",itemTypeId="3000000001901",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Medium Vault",price=1200000,ed_price=0}
DATA[55]={id = 55,gameid="",shopId="1002",itemTypeId="3000000002001",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Large Vault",price=1800000,ed_price=0}
DATA[56]={id = 56,gameid="",shopId="1002",itemTypeId="3000000002101",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Magical Bucket",price=2400000,ed_price=0}
DATA[57]={id = 57,gameid="",shopId="1002",itemTypeId="3000000002201",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="More Magical Magical Bucket",price=5500000,ed_price=0}
DATA[58]={id = 58,gameid="",shopId="1002",itemTypeId="3000000002301",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Hexa Pack",price=8000000,ed_price=0}
DATA[59]={id = 59,gameid="",shopId="1002",itemTypeId="3000000002401",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Deluxo 3000",price=17000000,ed_price=0}
DATA[60]={id = 60,gameid="",shopId="1002",itemTypeId="3000000002501",res_id="a192e9ff-7d25-4700-a14c-a34f5f3eaad6",name="Ultra Hexa Pack",price=29000000,ed_price=0}
return DATA
