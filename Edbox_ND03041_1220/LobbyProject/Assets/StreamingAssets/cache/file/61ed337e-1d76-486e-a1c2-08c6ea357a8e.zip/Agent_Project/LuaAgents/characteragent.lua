local json = require ("dkjson")
--local ActorActControl = require("actoractcontrol")
--local CharacterMove = require ("charactermvoe")

require ("common")
local CONFIG = require("config")
local host = CONFIG.MMO_HTTP_SERVER_HOST
local port = CONFIG.MMO_HTTP_SERVER_PORT

agent CharacterAgent = 
{
	repnotify(Rep_PlayerId) playerId = 0,		   -- 角色ID（平台playerId）
	nGameId = 0,			   					   -- 游戏ID
	repnotify(Rep_Name) playerName = "",		   -- 角色名称（平台名称）
	-- repnotify(Rep_LookFace) lookFace = {}       -- todo 拆分外观属性

	characterControl = {},						   -- 角色控制	
	characterMove = {},							   -- 角色移动

	--repnotify(Rep_pc) _playercontrol = {},		   -- 角色控制器

	-- 同步数据

	nMoveTimeStamp = 0,                            --客户端进行请求时候，记录下时间
	bMove = false,   
	nSpeed = 1,
	bCreatCharacter = false,
	--repnotify(Rep_ActminingRep) nActmining = 0,		-- 同步挖矿动作 0停止 1开始

	repnotify(Rep_CurPos) vCurPos = Vector3(0,0,0),
	vTargetPos = Vector3(0,0,0),
	vDirection = Vector3(0,0,0),
	actionType = 0,

	repnotify(Rep_MoveData) _moveData = {vCurPos = Vector3(0,0,0),vTargetPos = Vector3(0,0,0),vDirection = Vector3(0,0,0),actionType = 0},	   

	_audioAction = 0,							-- 动作声音

	_characterActControl = {}					-- 人物动作控制
}


function CharacterAgent:getPlayerId()
	return self.playerId;
end

function CharacterAgent:getMoney()
	return self.nMoney;
end

function CharacterAgent:setMoney(nVal)
	if(type(nVal) == "number") then
		print("nVal = " .. nVal)
		self.nMoney = nVal;
		print("after setMoney, = " .. self.nMoney)
	end
end

-- 角色加载时获取金钱
function CharacterAgent:getMoneyRes(nVal)
	print("nVal = " .. nVal)
	print(type(nVal))
	local obj, pos, err = json.decode (nVal, 1, nil)
	local value = {}
	if(type(obj.data.value) == "string")then
		local obj_, pos_, err_ = json.decode (obj.data.value, 1, nil)
		value = obj_
	end
	
	if value.money == nil then
		self.nMoney = 0;
	else
		if(value.money>1000000000) then
			self.nMoney = 1000000000
		end
		self.nMoney = value.money;
	end
	print("after getMoneyRes, = " .. self.nMoney)
end

function CharacterAgent:Initialize()
	print("CharacterAgent:Initialize:"..tostring(self))
	self:SetReplicate(true)
	self:SetNetUpdate(100)
	
	self:AddComponent('AgentSystemExtension.AgentComponent_Common')
	self:AddComponent('EbAgentGame.AgentComponent_ClientCharacter')
	self:AddComponent('EbAgentGame.AgentComponent_CharacterState')
	self:AddComponent('EbAgentGame.AgentComponent_ScenePoint')
	self:AddComponent('ActionSystemCommon.AgentComponent_Audio')
end

function CharacterAgent:OnStart()	
	print("CharacterAgent:OnStart:"..tostring(self)) 
	-- self:CreateSceneCharacter();
	-- 动作控制器
	self.characterControl = CharacterControl:New(self)
	self.characterControl:SetOwner(self)
	self:CreateSceneCharacter()
end


function CharacterAgent:Rep_CurPos()
	--print("~~~~~~~~~~~~~~CharacterAgent:Rep_CharacterCurPos")

	if self:HasAuthority() or self:IsLocally() then return end

	self:CreateOtherCharacter()

end	


function CharacterAgent:LoadActorControl()
	print("LoadActorControl-Client....")
	--self:CreateActorControl()
end

-- 设置角色playerId
function CharacterAgent:setPIdClient(playerId)
	print("setPId-Client....")
	self:setPIdServer(playerId)
end

reliableserverfunction CharacterAgent:setPIdServer(playerId)
	print("setPId Server....")
	self.playerId = playerId
	print("self.playerId...." .. self.playerId)
end

-- 设置游戏Id
function CharacterAgent:setGIdClient(nGameId)
	print("setGId-Client....")
	self:setGIdServer(nGameId)
end

reliableserverfunction CharacterAgent:setGIdServer(nGameId)
	print("setGId-Server....")
	self.nGameId = nGameId
	print("self.setGIdServer...." .. self.nGameId)
end

-- 加载角色信息
function CharacterAgent:LoadCharacter(clientParams)
	print("LoadCharacter *******************************************")
	self:LoadFromServer(clientParams)
end

reliableserverfunction CharacterAgent:LoadFromServer(clientParams)
	print("LoadFromServer *******************************************")
	self.Character:LoadCharacterInfo(clientParams)
	self.Character:LoadCharacterInfo(host, port, clientParams)
end

-- 角色组件通过回调将数据返回
function CharacterAgent:OnLoadCharacterInfo(result)
	print("lua callback is doing *******************************************")
	print(result)
	local obj, pos, err = json.decode (result, 1, nil)
	print(type(obj.playerName))
	print(obj.playerName)
	self.playerName = obj.playerName
	print("self.playerName = " .. self.playerName)
	--self.lookFace = result.lookFace
end

-- 购买商店物品(客户端请求购买 -> 服务端serverfunction处理 -> 调用客户端clietnfunction告知客户端购买结果)
function CharacterAgent:BuyClient(shopItemId, itemNum)

end

reliableserverfunction CharacterAgent:BuyServer(shopItemId, itemNum)
	
end

function CharacterAgent:setMoneyToDB(list)
    
end

-- 购买商品结果
clientfunction CharacterAgent:SendBuyResult(buyResult)

end

-- 通知客户端角色ID已获取
function CharacterAgent:Rep_PlayerId()
	print("PlayerID_Notify *******************************************" .. self.playerId)
	self.ClientCharacter:GetGamePlayer(self.playerId) -- 新增通知
end

-- 通知客户端角色控制器已获取
function CharacterAgent:Rep_PlayerControl()
	print("Rep_PlayerControl *******************************************" )
	if not self:HasAuthority() then
		--绑定装备按钮
		--self._playercontrol.Input:BindKeyDown(self.OnEquipClick, tkeys.T)
	end

end	

-- 通知客户端角色名已获取
function CharacterAgent:Rep_Name()
	print("PlayerName_Notify *******************************************" .. self.playerName)
	self.ClientCharacter:NameChanged(self.playerName) 
end

-- 通知客户端金钱值改变
function CharacterAgent:Rep_Money()
	if (not self:HasAuthority()) and self:IsLocally() then
		print("Money_Change *******************************************" .. self.nMoney)
		self.ClientCharacter:MoneyChanged(self.nMoney) 
	end
end

-- 从DataStore获取角色金钱
function CharacterAgent:GetMoneyClient()
	print("getMoneyClient is invoking here....")
	self:GetMoneyServer()
end

reliableserverfunction CharacterAgent:GetMoneyServer()
	-- print("getMoneyServer is invoking here....")
	-- print("money = " .. self.nMoney)

    -- local storeKey =  self.nGameId .. "." .. self.playerId .. ".money" 
	-- print("storeKey = " .. storeKey)
    -- local sendData = {}
    -- sendData.storeKey = storeKey
    -- sendData.apiName = "get"
    -- sendData = json.encode(sendData)
	-- print("setData= " .. sendData)
    -- self.DataStore:DataStoreOperation(host, port, sendData, "getMoneyRes") --调用DataStore组件
end

-- 角色退出游戏时调用
function CharacterAgent:OnDestroy()
	print("Character OnDestroy....")

	if (not self:HasAuthority()) then
		self.CharacterState:DestoryCharacter();
		self.ClientCharacter:DestoryOb();
	end
end

function CharacterAgent:OnUpdate(DeltaTime)
	
	if self:HasAuthority() then
		--移动的数据 定时 进行判断处理
		self:processMove()
	else
		
		if (self.actionType == 3) then
			if (self._audioAction ~= self.actionType) then
				self.Audio:PlayAudio("0619b47d-e435-4e2e-83ea-2f141e063668", true)
				self._audioAction = self.actionType
			end
				
		elseif (self._audioAction ~= self.actionType) then
			self.Audio:StopAudio();
			self._audioAction = self.actionType;

		end		
	end
end

---------------------------------- 同步玩家位置 -----------------------------------
function CharacterAgent:Rep_MoveData()
	print("~~~~~~~~~~~~CharacterAgent:Rep_MoveData")
end

--客户端调用停止移动
serverfunction CharacterAgent:SrvMoveStop(vTargetPos, actionType, nTimeStamp)	
	self:SrvStop(vTargetPos, actionType, nTimeStamp)
end

--服务端处理移动数据
reliableserverfunction CharacterAgent:SrvStop(vTargetPos, actionType, nTimeStamp)

	--float类型做精度处理
	local nOldTargetPosX = math.floor(self.vTargetPos.x*100+0.5)*0.01
	local nOldTargetPosY = math.floor(self.vTargetPos.y*100+0.5)*0.01
	local nOldTargetPosZ = math.floor(self.vTargetPos.z*100+0.5)*0.01

	local nNewTargetPosX = math.floor(vTargetPos.x*100+0.5)*0.01
	local nNewTargetPosY = math.floor(vTargetPos.y*100+0.5)*0.01
	local nNewTargetPosZ = math.floor(vTargetPos.z*100+0.5)*0.01

	--目标位置与之前的目标位置相等时，不处理
	if(nOldTargetPosX == nNewTargetPosX and nOldTargetPosY == nNewTargetPosY and nOldTargetPosZ == nNewTargetPosZ) then
		return
	end

	--进行移动处理
	self.bMove = false	
	self.vDirection = Vector3(0,0,0)
	self.actionType = actionType
	self.vTargetPos = vTargetPos;
	self.vCurPos = vTargetPos;
	-- self.nMoveTimeStamp = self.Common:GetTimeStamp()


	self:BroadCastStopData(self.vCurPos, self.vTargetPos, self.vDirection,self.actionType, nTimeStamp);
	--self.moveState = {curPosX = fromPosX, curPosY = fromPosY, curPosZ = fromPosZ, targetX = toPosX, targetY = toPosY, targetZ = toPosZ, dirX = vDirection.x, dirY = vDirection.y, dirZ = vDirection.z, nTimeStamp = self.nMoveTimeStamp };
end


--服务端处理移动数据
reliableserverfunction CharacterAgent:SrvMove(vCurPos, vTargetPos, vDirection, actionType, nTimeStamp)

	--float类型做精度处理
	local nOldTargetPosX = math.floor(self.vTargetPos.x*100+0.5)*0.01
	local nOldTargetPosY = math.floor(self.vTargetPos.y*100+0.5)*0.01
	local nOldTargetPosZ = math.floor(self.vTargetPos.z*100+0.5)*0.01

	local nNewTargetPosX = math.floor(vTargetPos.x*100+0.5)*0.01
	local nNewTargetPosY = math.floor(vTargetPos.y*100+0.5)*0.01
	local nNewTargetPosZ = math.floor(vTargetPos.z*100+0.5)*0.01

	--目标位置与之前的目标位置相等时，不处理
	if (actionType == self.actionType) and (nOldTargetPosX == nNewTargetPosX and nOldTargetPosY == nNewTargetPosY and nOldTargetPosZ == nNewTargetPosZ) then
		return
	end


	local nCurPosX = math.floor(self.vCurPos.x*100+0.5)*0.01
	local nCurPosY = math.floor(self.vCurPos.y*100+0.5)*0.01
	local nCurPosZ = math.floor(self.vCurPos.z*100+0.5)*0.01

	--目标位置与角色当前位置相等且动作相同时，不处理
	if (actionType == self.actionType) and (nCurPosX == nNewTargetPosX and nCurPosY == nNewTargetPosY and nCurPosZ == nNewTargetPosZ) then
		return
	end

	--进行移动处理
	self.bMove = true	
	self.vDirection = vDirection
	self.actionType = actionType
	self.vCurPos = Vector3(vCurPos.x, vCurPos.y, vCurPos.z)
	self.vTargetPos = vTargetPos
	-- self.nMoveTimeStamp = self.Common:GetTimeStamp()

	self:BroadCastMoveData(vCurPos, vTargetPos, vDirection, actionType, nTimeStamp);
	--self.moveState = {curPosX = fromPosX, curPosY = fromPosY, curPosZ = fromPosZ, targetX = toPosX, targetY = toPosY, targetZ = toPosZ, dirX = vDirection.x, dirY = vDirection.y, dirZ = vDirection.z, nTimeStamp = self.nMoveTimeStamp };
end


broadcastfunction CharacterAgent:BroadCastMoveData(vCurPos, vTarget, vDir, actionType, nTime)
	self:UpdateMoveData(vCurPos, vTarget, vDir, actionType, nTime);
end

broadcastfunction CharacterAgent:BroadCastStopData(vCurPos, vTarget, vDir, actionType, nTime)
	self:UpdateStopData(vCurPos, vTarget, vDir, actionType, nTime);
end


function CharacterAgent:UpdateMoveData(vCurPos, vTarget, vDir, actionType, nTime)
	if  self:IsLocally() then return end

	--print("!!!!!!!!!!!!CharacterAgent:UpdateMoveData");

	self.CharacterState:OnRep_ReplicateMove(vCurPos, vTarget, vDir,actionType, nTime)

end

function CharacterAgent:UpdateStopData(vCurPos, vTarget, vDir, actionType, nTime)

	if  self:IsLocally() then return end

	--print("#####################CharacterAgent:UpdateStopData");
	self.CharacterState:OnRep_ReplicateStop(vCurPos, vTarget, vDir, actionType, nTime)

	--self.Audio:StopAudio();

	self._audioAction = 0;
end	


--服务端对移动的数据 定时 进行判断处理
function CharacterAgent:processMove()
	-- if (self.bMove == false) then --角色没有移动，不需要处理
	-- end

	-- local nCurTimeStamp = self.Common:GetTimeStamp()
	-- local nDiffTime = nCurTimeStamp - self.nMoveTimeStamp --时间间隔
	-- local nMoveDistance = nDiffTime * self.nSpeed  --移动距离
	-- local nMaxDistance = getDis(self.vCurPos, self.vTargetPos) --当前位置与目标位置距离
	-- self.nMoveTimeStamp = self.Common:GetTimeStamp() --processMove定时运行，更新下时间

	-- if(nMoveDistance >= nMaxDistance) then
	-- 	self.bMove = fasle
	-- 	self.vCurPos = self.vTargetPos
	-- 	return
	-- end
 
    -- --processMove定时运行，bMove = true,下一次会进来，（隔一段时间移动一小段，更新当前位置）
    -- local nDistance = nMaxDistance - nMoveDistance;
	--移动一段距离后，移动后的位置 设置成 当前位置

	--self.vCurPos = getPos(self.vCurPos, self.vTargetPos, nDistance)
end

function CharacterAgent:getCurPos()
    return self.vCurPos;
end


-- 创建场景人物角色
function CharacterAgent:CreateSceneCharacter()

	if self.bCreatCharacter then return end

	-- 玩家自身
	self.playerId = 1;
	-- self.vCurPos = Vector3(-0.3, 1, -15)
	self.vCurPos = Vector3.zero
	self.CharacterState:CreateCharacter(self.playerId, self.vCurPos, "893e7bc3-cd71-4899-acc5-a0fcd0cc9838")
	self.bCreatCharacter = true;

	-- print("******************************************* CreateSceneCharacter "..self.playerId);
end


function CharacterAgent:CreateOtherCharacter()
	--print("!!!!!!!!!!!!!!!!!!!!CharacterAgent:CreateOtherCharacter PlayerId is "..self.playerId)
	if self:HasAuthority() or self:IsLocally() then return end

	if self.bCreatCharacter then return end

	self.playerId = 999;
	self.CharacterState:CreateCharacter(self.playerId, self.vCurPos);
	self.bCreatCharacter = true;
end

function CharacterAgent:OneStampFinish(curPos, dir, motionState)
end

-- 创建场景人物角色成功
function CharacterAgent:OnFinishCharacter()	
	self.ClientCharacter:RefreshPlugin();

	-- self.characterControl:Init(self.playerId)

	-- self:AddComponent('EbAgentGame.AgentComponent_CharacterSync')
	
	-- self.CharacterSync:Init()

	-- self.CharacterSync:SetSyncCallBack('CharacterMove', 'CharacterStop', 'CharacterFlash', 'OneStampFinish')

	-- if (self:IsLocally()) then
	-- 	local randomPos = self.ClientCharacter:GetBornPosition()
	-- 	self.vCurPos = Vector3(randomPos.x, randomPos.y, randomPos.z)
	-- 	--print("========================================random pos : "..randomPos.x..","..randomPos.y..","..randomPos.z.."=============================================")
	-- 	self.CharacterState:UpdateHeroPos(self.vCurPos)

	
	-- end
end

-- C#同步人物位置
function CharacterAgent:CharacterMove(fromPosX, fromPosY, fromPosZ, toPosX, toPosY, toPosZ, dirX, dirY, dirZ, actionType, nTimeStamp)

	self.vCurPos = Vector3(fromPosX, fromPosY, fromPosZ);
	self.vDirection = Vector3(dirX, dirY, dirZ);
	self.vTargetPos = Vector3(toPosX, toPosY, toPosZ);
	self.actionType = actionType
	self.nMoveTimeStamp = nTimeStamp
	--print("************************CharacterAgent:CharacterMove ");

	self:SrvMove(self.vCurPos, self.vTargetPos, self.vDirection, self.actionType, self.nMoveTimeStamp);
	
end

function CharacterAgent:CharacterStop(vCurPosX, vCurPosY, vCurPosZ, action, nTimeStamp)
	--local sMoveData = json.encode({playerId = self.playerId, vCurPos = fromPos,vTargetPos = toPos, vDirection = dir ,actionType = action});
	--print(sMoveData);
	--print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CharacterStop");
	self.vTargetPos = Vector3(vCurPosX,vCurPosY,vCurPosZ);
	self.actionType = action
	self.nMoveTimeStamp = nTimeStamp
	--self.vDirection = Vector3(vDirectionX,vDirectionY,vDirectionZ);
	self:SrvMoveStop(self.vTargetPos, self.actionType, self.nMoveTimeStamp);

	--self.Audio:StopAudio()
end


-- 瞬移
function CharacterAgent:CharacterFlashMove(vCurPosX, vCurPosY, vCurPosZ)
	self.vTargetPos = Vector3(vCurPosX,vCurPosY,vCurPosZ);
	self.vCurPos = Vector3(vCurPosX,vCurPosY,vCurPosZ);

	self:SrvFlashMove(self.vTargetPos);
end

-- 同步玩家动作
function CharacterAgent:toSurface()
	local surfacePoint = self.ScenePoint:GetPoint("ToSurface");
	self.ClientCharacter:ToPosition(surfacePoint)
	self.actionType = action;
end

serverfunction CharacterAgent:SrvFlashMove(vTargetPos)
	self:BroadCastFlashMove(vTargetPos)
end

broadcastfunction CharacterAgent:BroadCastFlashMove(vTargetPos)
	self.vTargetPos = vTargetPos;
	self.vCurPos = vTargetPos;
	self:UpCltFlashMove(self.vTargetPos, self.vDirection, self.actionType);
end

function CharacterAgent:UpCltFlashMove(vTargetPos, vDirection, actionType)

	if not self:IsLocally() then

		self.vTargetPos = vTargetPos;
		self.vCurPos = vTargetPos;
		self.actionType = actionType;
		self.vDirection = vDirection;
		self.CharacterState:OnRep_ReplicatePos(vTargetPos, vDirection, actionType, 0);
	end	
end	
