
---
-- @function: 获取table的字符串格式内容，递归
-- @tab： table
-- @ind：不用传此参数，递归用（前缀格式（空格））
-- @return: format string of the table
function dumpTab(tab,ind)
    if(tab==nil)then return "nil" end;
    local str="{";
    if(ind==nil)then ind="  "; end;
    --//each of table
    for k,v in pairs(tab) do
      --//key
      if(type(k)=="string")then
        k=tostring(k).." = ";
      else
        k="["..tostring(k).."] = ";
      end;--//end if
      --//value
      local s="";
      if(type(v)=="nil")then
        s="nil";
      elseif(type(v)=="boolean")then
        if(v) then s="true"; else s="false"; end;
      elseif(type(v)=="number")then
        s=v;
      elseif(type(v)=="string")then
        s="\""..v.."\"";
      elseif(type(v)=="table")then
        s=dumpTab(v,ind.."  ");
        s=string.sub(s,1,#s-1);
      elseif(type(v)=="function")then
        s="function : "..v;
      elseif(type(v)=="thread")then
        s="thread : "..tostring(v);
      elseif(type(v)=="userdata")then
        s="userdata : "..tostring(v);
      else
        s="nuknow : "..tostring(v);
      end;--//end if
      --//Contact
      str=str.."\n"..ind..k..s.." ,";
    end --//end for
    --//return the format string
    local sss=string.sub(str,1,#str-1);
    if(#ind>0)then ind=string.sub(ind,1,#ind-2) end;
    sss=sss.."\n"..ind.."}\n";
    return sss;--string.sub(str,1,#str-1).."\n"..ind.."}\n";
  end;--//end function
  
  --//网摘,直接打印到屏幕
  function printTable(t, n)
    if "table" ~= type(t) then
      return 0;
    end
    n = n or 0;
    local str_space = "";
    for i = 1, n do
      str_space = str_space.."  ";
    end
    print(str_space.."{");
    for k, v in pairs(t) do
      local str_k_v
      if(type(k)=="string")then
        str_k_v = str_space.."  "..tostring(k).." = ";
      else
        str_k_v = str_space.."  ["..tostring(k).."] = ";
      end
      if "table" == type(v) then
        print(str_k_v);
        printTable(v, n + 1);
      else
        if(type(v)=="string")then
          str_k_v = str_k_v.."\""..tostring(v).."\"";
        else
          str_k_v = str_k_v..tostring(v);
        end
        print(str_k_v);
      end
    end
    print(str_space.."}");
  end

  function getDis(pos1, pos2) 
    return math.sqrt(math.pow((pos1.x-pos2.x), 2) + math.pow((pos1.y-pos2.y), 2))
  end

  function getPos(start, target, dis) 
    length = getDis(start, target)
    pos = {}

    pos.x = target.x - (target.x-start.x) * (dis/length)
    pos.y = target.y - (target.y-start.y) * (dis/length)
    pos.z = target.z - (target.z-start.z) * (dis/length)

    return pos
  end


  function Prejudgement(equipe)
    -- 判断物品是否存在
    if (equipe == nil)then
      print("equipe no exit")
      return false
    end
    -- 判断物品类型是否正确
    if (equipe.type ~= 3)then
      print("equipe type error")
      return false
    end
    return true
  end
  
  function PrejudgementMine(mine)
    -- 判断物品是否存在
    if (mine ==nil)then
      print("mine no exit")
      return false
    end
    -- 判断物品类型是否正确
    if (mine.type ~=0 and mine.type ~=1 and mine.type ~=2)then
      print("mine type error")
      return false
    end
    return true
  end
  
  function isRequire(mine, equipe)
    --资管提供公式
    if(mine.weight/(equipe.speed_boost/10) > 37)then
      print ("equipe no use")
      return false
    else
      return true
    end
  end

  function deepCopy(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local new_table = {}
        lookup_table[object] = new_table
        for key, value in pairs(object) do
            new_table[_copy(key)] = _copy(value)
        end
        return setmetatable(new_table, getmetatable(object))
    end
    return _copy(object)
end