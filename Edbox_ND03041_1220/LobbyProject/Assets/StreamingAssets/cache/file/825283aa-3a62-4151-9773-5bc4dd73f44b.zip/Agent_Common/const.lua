module("Const", package.seeall)

ZERO = 0                                    -- 零 
ONE = 1                                     -- 壹
MONEY_NOT_ENOUGH = 1002                     -- 购买物品钱不够

INITIAL_BAG = 3000000000001                 -- 初始背包

INITIAL_EQUIPMENT = 2000100000001           -- 初始武器

BAG_TYPE = 4                                -- 背包类型

EQUIPMENT_TYPE = 3                          -- 装备类型
