function CreatEnumTable(tbl, index) 
    assert(type(tbl) == "table") 
    local enumtbl = {} 
    local enumindex = index or 0 
    for i, v in ipairs(tbl) do 
        enumtbl[v] = enumindex + i 
    end 
    return enumtbl 
end 

-- 枚举1, 2, 3
ROLE_TYPE = CreatEnumTable({
	"ONE", 
	"TWO", 
	"THREE", 
}, -1)
