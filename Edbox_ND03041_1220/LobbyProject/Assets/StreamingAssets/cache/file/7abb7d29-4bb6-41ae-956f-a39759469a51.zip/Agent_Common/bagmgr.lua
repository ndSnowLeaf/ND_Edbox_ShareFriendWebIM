require("common")
require("const")
local ItemType = require ("itemType")
local json = require("dkjson")
local CONFIG = require("config")
local host = CONFIG.MMO_HTTP_SERVER_HOST
local port = CONFIG.MMO_HTTP_SERVER_PORT

Bag = {
    usingBag = {},
    bags = {},
    items = {},
    owner = {}
}

Bag.__index = Bag

function Bag:new (owner)
    newBag = {}
    setmetatable(newBag, Bag)
    newBag.usingBag = {}
    newBag.bags = {}
    newBag.items = {}
    newBag.owner = owner
    return newBag
end

function Bag:setData(item)
    local setItem = {}
    setItem.itemTypeId = item.id or Const.ZERO;
    setItem.typeId = item.typeId or Const.ZERO;
    setItem.value = item.value or Const.ZERO;
    setItem.equip = item.equip or false;
    setItem.activation = item.activation or false;
    setItem.num = item.num or Const.ZERO;
    return setItem
end

-- 初始化
function Bag:initBag()   
    local storeKey = self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".bagData" 
    local sendData = {}
    sendData.storeKey = storeKey
    sendData.apiName = "get"
    sendData = json.encode(sendData)
    self.owner.DataStore:DataStoreOperation(host, port, sendData, "getBagRes")
end

function Bag:getBagRes(list)
    local list = json.decode(list)
    local data = list.data
    local bagData = {}
    if(type(data.value) == "string")then
        bagData = json.decode(data.value)
        if(type(bagData) ~= "table")then
            bagData = {}
        end
    end
    if(bagData == nil or (type(bagData) == "table" and (next(bagData) == nil)))then
        local bag = self:setData(ItemType[Const.INITIAL_BAG])
        bag.equip = true
        bag.activation = true
        bagData[bag.itemTypeId] = bag
    end
    if(type(self.bags) == "table" and next(self.bags) ~= nil) then
        print("bags must be empty first --------------<bags>" .. self.owner:getPlayerId())
    end

    for i, bag in pairs(bagData)
        do
        if(ItemType[bag.itemTypeId].type == Const.BAG_TYPE )then
            if(bag.equip == true and bag.activation == true) then
                self.usingBag = bag
            end
            self.bags[bag.itemTypeId] = bag;
        end
    end
    local storeKey =  self.owner.nGameId .. "." .. self.owner:getPlayerId()  .. ".itemsData" 
    local sendData = {}
    sendData.storeKey = storeKey
    sendData.apiName = "get"
    sendData = json.encode(sendData)
    self.owner.DataStore:DataStoreOperation(host, port, sendData, "getItemsRes")
end

function Bag:getItemsRes(list)
    local list = json.decode(list)
    local data = list.data

    local itemsData = {}
    if(type(data.value) == "string")then
        itemsData = json.decode(data.value)
        if(type(itemsData) ~= "table")then
            itemsData = {}
        end
    end
    local nBagCurLen = Const.ZERO
    for i, item in pairs(itemsData)
    do
        nBagCurLen = nBagCurLen + item.num
        self.items[item.itemTypeId] = item
        --table.insert(self.items, item)
    end
    self.owner:setBagType(self.usingBag.itemTypeId)
    self.owner:setBagLen(nBagCurLen)
    --[[
    local storeKey =  "gameId." .. self.owner.playerId .. ".money" 
    local sendData = {}
    sendData.storeKey = storeKey
    sendData.apiName = "get"
    sendData = json.encode(sendData)
    -- self.DataStore.DataStoreOperation(host, port, sendData, "endOfInitBag")
    ]]
end

--[[
function Bag:endOfInitBag(list)
   list = json.decode(list)
   self.owner.money = list.data.money
end


-- 检查背包剩余空间
function Bag:getStorageNum()
    return self.usingBag.emptyStorage
end

]]

-- 获取有的装备
function Bag:getBags()
    local bags = deepCopy(self.bags)
    return json.encode(bags)
end  

-- 添加物品
function Bag:putBag(items)
    if(items ~= nil and type(items) == "table") then
        local sendData = {}
        sendData.storeKey = self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".itemsData" 
        local nBagCurLen = self.owner:getBagLen()
        for i, v in pairs(items) 
            do 
            local item = self:setData(ItemType[i])
            local addition = false
            local bagFull = false
            local haveItem = deepCopy(self.items)
            for j, selfItem in pairs(haveItem)
                do
                if(item.itemTypeId == selfItem.itemTypeId) then
                    -- 有相同id的矿
                    if((ItemType[self.usingBag.itemTypeId].storage - nBagCurLen) == v) then
                        -- table.insert(self.items, item)
                        self.items[selfItem.itemTypeId].num = selfItem.num + v
                        sendData.nBagCurLen = ItemType[self.usingBag.itemTypeId].storage
                        addition = true
                        bagFull = true
                        break
                    elseif((ItemType[self.usingBag.itemTypeId].storage- nBagCurLen) > v)then 
                        -- table.insert(self.items, item)
                        self.items[selfItem.itemTypeId].num = selfItem.num + v
                        nBagCurLen = nBagCurLen + v
                        sendData.nBagCurLen = nBagCurLen
                        addition = true
                        break
                    elseif((ItemType[self.usingBag.itemTypeId].storage- nBagCurLen) < v) then
                        self.items[selfItem.itemTypeId].num = selfItem.num + (ItemType[self.usingBag.itemTypeId].storage- nBagCurLen)
                        sendData.nBagCurLen = ItemType[self.usingBag.itemTypeId].storage
                        addition = true
                        bagFull = true
                        break
                    end
                end
            end
            if(bagFull) then
                -- 包满退出
                break
            else
                if(addition == false) then
                   if((ItemType[self.usingBag.itemTypeId].storage - nBagCurLen) == v) then
                        --table.insert(self.items, item)
                        item.num = v
                        self.items[item.itemTypeId] = item
                        sendData.nBagCurLen = ItemType[self.usingBag.itemTypeId].storage
                        break
                    elseif((ItemType[self.usingBag.itemTypeId].storage- nBagCurLen) > v)then 
                        -- table.insert(self.items, item)
                        item.num = v
                        self.items[item.itemTypeId] = item
                        nBagCurLen = nBagCurLen + v
                        sendData.nBagCurLen = nBagCurLen
                    elseif((ItemType[self.usingBag.itemTypeId].storage- nBagCurLen) < v) then
                        item.num = ItemType[self.usingBag.itemTypeId].storage- nBagCurLen
                        self.items[item.itemTypeId] = item
                        sendData.nBagCurLen = ItemType[self.usingBag.itemTypeId].storage
                        break
                    end
                end
            end
        end 
        sendData.value = json.encode(deepCopy(self.items))
        sendData.apiName = "set"
        sendData = json.encode(sendData)
        self.owner.DataStore:DataStoreOperation(host, port, sendData, "addItemRes")
    else
        print("没有收到物品")
        return false
    end
end

function Bag:addItemRes(list)
    local list = json.decode(list)
    local data = list.data
    self.owner:setBagLen(data.nBagCurLen)
end

-- 添加背包
function Bag:addBag(bagId)
    if(bagId ~= nil) then
        if(ItemType[bagId] ~= nil) then
            local itemTypeId = self.owner.nBagType -- owner需要get方法 -- 获取玩家装备的背包
            if(itemTypeId ~= nil and itemTypeId ~= Const.ZERO and bagId ~= itemTypeId) then
                local old  = deepCopy(self.bags[itemTypeId])
                old.equip = false
                old.activation = false
                self.bags[itemTypeId] = nil
                self.bags[itemTypeId] = old
            else
                return false
            end
            self.usingBag = nil
            
            local newBag = self:setData(ItemType[bagId])
            newBag.equip = true
            newBag.activation = true
            self.usingBag = newBag
            -- table.insert(self.bags, bag.itemTypeId, bag)
            self.bags[newBag.itemTypeId] = newBag

            local sendData = {}
            sendData.storeKey = self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".bagData" 
            sendData.apiName = "set"
            sendData.value = json.encode(deepCopy(self.bags))
            sendData = json.encode(sendData)
            self.owner.DataStore:DataStoreOperation(host, port, sendData, "addBagsRes")
        else
            return false
        end
    end
end

function Bag:addBagsRes(list)
    local list = json.decode(list)
    local data = list.data
    self.owner:setBagType(self.usingBag.itemTypeId)
    -- self.owner:setBagLen(0)
    self.owner:GetAllBagServer()
end

-- 换背包
function Bag:exchange(bagId)
    if(self.bags[bagId] ~= nil and (bagId ~= self.usingBag.itemTypeId)) then
        local oldBag = deepCopy(self.usingBag)
        oldBag.equip = false
        oldBag.activation = false
        self.bags[oldBag.itemTypeId] = nil
        self.bags[oldBag.itemTypeId] = oldBag

        local newBag = self:setData(ItemType[bagId])
        newBag.equip = true
        newBag.activation = true
        self.bags[newBag.itemTypeId] = nil
        self.bags[newBag.itemTypeId] = newBag
        self.usingBag = nil
        self.usingBag = newBag

        local sendData = {}
        sendData.storeKey = self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".bagData" 
        sendData.value = json.encode(deepCopy(self.bags))
        sendData.apiName = "set"
        sendData = json.encode(sendData)
        self.owner.DataStore:DataStoreOperation(host, port, sendData, "exchangeRes")
        return true
    else
        return false
    end
end

function Bag:exchangeRes(list)
    local list = json.decode(list)
    local data = list.data
    self.owner:setBagType(self.usingBag.itemTypeId) 
    -- self.owner:setBagLen(0)
    self.owner:GetAllBagServer()
end

-- 卖掉物品
function Bag:sellItem(type)
    if(type == "mine") then
        if(self.owner:getBagLen() ~= Const.ZERO) then 
            local items = deepCopy(self.items)
            local salePrice = Const.ZERO
            for i, item in pairs(items) 
                do 
                print("id---------------------:"..item.itemTypeId .. "num...................:".. item.num.. "................value:".. item.value)
                salePrice= item.num * item.value + salePrice
            end 
            local sendData = {}
            sendData.storeKey = self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".itemsData" 
            sendData.resUrl = "delItemsRes"
            sendData.salePrice = salePrice
            sendData.apiName = "del"
            sendData = json.encode(sendData)
            self.owner.DataStore:DataStoreOperation(host, port, sendData, "delItemsRes")
            return true
        else
            return false
        end
    end
end

function Bag:delItemsRes(list)
    -- 清掉内存物品 
    self.items = nil
    self.items = {}
    local list = json.decode(list)
    local data = list.data
    local money = self.owner:getMoney() + data.salePrice
    local sendData = {}
    sendData.storeKey = self.owner.nGameId .. "." .. self.owner:getPlayerId() .. ".money" 
    local value = {}
    value.money = money
    sendData.value = json.encode(value)
    sendData.apiName = "set"
    sendData = json.encode(sendData)
    self.owner:setBagLen(Const.ZERO)
    self.owner.DataStore:DataStoreOperation(host, port, sendData, "bgMsetMoneyRes")    
end

function Bag:bgMsetMoneyRes(list)
    list = json.decode(list)
    local data = list.data
    local value = {}
    if(type(data.value) == "string") then
        value = json.decode(data.value)
    end
    self.owner:setMoney(value.money)
end

return Bag