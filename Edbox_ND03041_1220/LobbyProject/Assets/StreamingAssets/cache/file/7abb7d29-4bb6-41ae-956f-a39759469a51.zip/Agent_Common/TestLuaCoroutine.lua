local coDelay = nil

function Delay()
	local c = 1

	while true do
		coroutine.wait(1)
		print("Count: "..c)
		c = c + 1
	end
end

function StartDelay()
	coDelay = coroutine.start(Delay)
end

function StopDelay()
	coroutine.stop(coDelay)
end

StartDelay()
