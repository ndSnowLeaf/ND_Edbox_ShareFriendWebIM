require "plus"
require "CommonLogic"

game Game = 
{
	characterList = {},
	shop = {},
	pageGuid = {},
	pageIndex = 1,
	pageInstId = nil,
	pageTitle = {},
	isAnimating = 0,
	timeSpan = 0
}

function Game:Initialize()
	self:SetNetUpdate(100)
	self:AddComponent('EbAgentCommon.AgentComponent_Config')
	self:AddComponent('EbAgentCommon.AgentComponent_Language')
	self:AddComponent('EbAgentGame.AgentComponent_Scene')
	self:AddComponent('EbAgentGame.AgentComponent_UI')
	self:AddComponent('EbAgentGame.AgentComponent_LoadUI')	
	self:AddComponent('EbAgentGame.AgentComponent_CharacterOb')
	self:AddComponent('EbRunner.AgentComponent_Runner')	
	self:AddComponent('EbAgentCommon.AgentComponent_Input')
end

function Game:SetProgress(tip, bp, ep, cb)
	self.LoadUI:SetTipAndProgress(tip, bp, ep, cb)
	--print("tip :=======================================================" .. tip)
end

function Game:OnUpdate(deltaTime)
	CommonLogic.OnUpdate(deltaTime)
end

local basePath
function Game:OnStart()	
	self.Runner:HideMainUI()
	self.Runner:InitDatas()
	
	local languageType = self.Config:GetLanguageType();
	self.Language:Init(languageType, "");

	-- local uiKey = self.Config:GetValue("uiKey");
	local uiKey = self.Runner:GetUIResId()
	self.UI:Init(uiKey, "StartUILoadFinish")	
end

function Game:StartUILoadFinish()
	self.Runner:AddGamePlay(self.OnGamePlay)
end

function Game:OnGamePlay()
	local text = self.Language:GetContent("Load.Scene");
	self:SetProgress(text, 0, 20)
    basePath = self.Config:GetBasePath()
	-- local sceneId = self.Config:GetValue("sceneKey");
	local sceneId = self.Runner:GetSceneResId()
	self.Scene:Init(sceneId, "SceneLoadFinish")
end

function Game:SceneLoadFinish(isConnect)
	local text = self.Language:GetContent("Load.UI");
	self:SetProgress(text, 20, 30)	
	-- local uiKey = self.Config:GetValue("uiKey");
	local uiKey = self.Runner:GetUIResId()
	self.UI:Init(uiKey, "UILoadFinish")	
end

function Game:UILoadFinish()	
	self:SetProgress(text, 30, 50)
	self.Scene:LoadAllRes("LocalResLoadFinish")
end

function Game:LocalResLoadFinish()	
	self.Scene:LoadLocalRes("ResLoadFinish")
end

function Game:ResLoadFinish()
	self:SetProgress(text, 50, 70)
	local text = self.Language:GetContent("Load.Character");	

	local newCharacter = CharacterAgent:New()
	table.insert(self.characterList, newCharacter)

	-- local characterId = self.Config:GetValue("characterKey");
	local characterId = self.Runner:GetCharacterResId()
	self.CharacterOb:Init(characterId, "CharacterLoadFinish")
end

function Game:CharacterLoadFinish()	
	if #self.characterList > 0 and self.characterList[1].characterControl ~= nil then	
		self.characterList[1].characterControl:ResetCharacterController(self.characterList[1].playerId)	
	end

	local text = self.Language:GetContent("Load.Runner");
	self:SetProgress(text, 70, 99, self.OnLoadingComplete)

	self.Runner:InitComponents("RunnerInitFinish")	
	-- if #self.characterList > 0 and self.characterList[1].characterControl ~= nil then		
	-- 	self.characterList[1].characterControl:OnInited()
	-- end
end

function Game:AllLoaded()
	if self.isLoaded and self.isRunnerInitFinish then
		local text = self.Language:GetContent("Load.All");
		self:SetProgress(text, 99, 100)

		self.Scene:Play()

		self.Runner:Inited()
		self.Runner:PlayBackgroundMusic()			
		
		if #self.characterList > 0 and self.characterList[1].characterControl ~= nil then	
			self.characterList[1].characterControl:InitCharacter(self.characterList[1].playerId)
			-- self.characterList[1].characterControl:OnInited()	
			-- self.characterList[1].characterControl:ResetEditorRoleTransform()
			-- self.characterList[1].characterControl.CharacterSync:FlashMoveTo(Vector3(0, 1, -12))			
			-- self.characterList[1].characterControl:SwitchAutoRun(true)
		end
	end
end

function Game:OnLoadingComplete()
	self.isLoaded = true
	self:AllLoaded()
end

function Game:RunnerInitFinish()
	self.isRunnerInitFinish = true
	self:AllLoaded()	
end
------------------

--[[
	function Game:CharacterLoadFinish()	
	self:SetProgress(text, 75, 90)

	local newCharacter = CharacterAgent:New()
	table.insert(self.characterList, newCharacter)

	self.Scene:LoadAllRes("ResLoadFinish")
end

function Game:ResLoadFinish()
	local text = self.Language:GetContent("Load.Res");
	self:SetProgress(text, 90, 100)
	self.Runner:PlayBackgroundMusic()
	self.Scene:Play()	
end
--]]

function Game:PostLogin(playerControl)
	-- local newCharacter = CharacterAgent:New(playerControl)
	-- newCharacter:SetOwner(playerControl)
	-- playerControl._character = newCharacter
	-- newCharacter._playercontrol = playerControl
	-- newCharacter.posInList = #self.characterList + 1

	-- table.insert(self.characterList, character)
end

function Game:PostLogout(playerControl)
	-- local character = playerControl:GetControlCharacter()
	-- if character ~= {} then
	-- 	character:Destroy()
	-- 	print("destorysssssssssssssss")
	-- end
	-- table.remove(self.characterList, character.posInList)
	
	-- playerControl:Logout()
	-- playerControl:Destroy()
end
