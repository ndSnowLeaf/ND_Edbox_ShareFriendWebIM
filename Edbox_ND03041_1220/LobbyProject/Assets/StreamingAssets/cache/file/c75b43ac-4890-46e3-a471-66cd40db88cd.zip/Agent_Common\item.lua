local itemType = require("itemtype")

agent Item = {
    itemTypeId = 0,
    typeId = 0,
    equip=false,
    activation=false,
    emptyStorage = 0,
    replicate num = 0
 }

function Item:setData(item)
    self.itemTypeId = item.id or 1;
    self.typeId = item.typeId or 1;
    self.equip = item.equip or 1;
    self.activation = item.activation or 1;
    self.emptyStorage = item.emptyStorage or 1;
    self.num = item.num or 1;
end

function Item:getDate()
    
end

function Item:getTypeData(idType)
    return itemType[idType]
end

function Item:getData(key)

end

function Item:setData(key, value)
    
end

return Item