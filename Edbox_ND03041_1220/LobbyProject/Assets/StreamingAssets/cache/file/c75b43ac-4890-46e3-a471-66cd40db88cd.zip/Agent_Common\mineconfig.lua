DATA={}


DATA["refreshTime"]=1500--刷新矿区间隔


return DATA