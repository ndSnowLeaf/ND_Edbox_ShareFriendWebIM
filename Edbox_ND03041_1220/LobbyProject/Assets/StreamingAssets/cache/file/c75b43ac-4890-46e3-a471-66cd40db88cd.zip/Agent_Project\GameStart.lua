require "plus"
require "CommonLogic"

game Game = 
{
	shop = {},
	pageGuid = {},
	pageIndex = 1,
	pageInstId = nil,
	pageTitle = {},
	isAnimating = 0,
	timeSpan = 0
}

function Game:Initialize()
	self:SetNetUpdate(100)
	self:AddComponent('EbAgentCommon.AgentComponent_Config')
	self:AddComponent('EbAgentCommon.AgentComponent_Language')
	self:AddComponent('EbAgentGame.AgentComponent_Scene')
	self:AddComponent('EbAgentGame.AgentComponent_UI')
	self:AddComponent('EbAgentGame.AgentComponent_LoadUI')
	self:AddComponent('EbAgentFiveChess.AgentComponent_FiveChess')
end

function Game:SetProgress(tip, bp, ep)
	self.LoadUI:SetTipAndProgress(tip, bp, ep)
	--print("tip :=======================================================" .. tip)
end

local basePath
function Game:OnStart()
	local languageType = self.Config:GetLanguageType();
	self.Language:Init(languageType, "");
	local text = self.Language:GetContent("Load.Scene");
	self:SetProgress(text, 0, 30)
    basePath=self.Config:GetBasePath()
	local sceneId = self.Config:GetValue("sceneKey");
	self.Scene:Init(sceneId, "SceneLoadFinish")
end

function Game:OnUpdate(deltaTime)
	CommonLogic.OnUpdate(deltaTime)
end

function Game:SceneLoadFinish(isConnect)
	self:SetProgress(text, 30, 60)
	local text = self.Language:GetContent("Load.UI");
	local uiKey = self.Config:GetValue("uiKey");
	self.UI:Init(uiKey, "UILoadFinish")
end

function Game:UILoadFinish()
	self:SetProgress(text, 65, 95)
	local text = self.Language:GetContent("Load.UI");
	self.Scene:LoadAllRes("ResLoadFinish")
end

function Game:ResLoadFinish()
	local text = self.Language:GetContent("Load.Complete");
	self:SetProgress(text, 95, 100)
	self.FiveChess:PlayBackgroundMusic()
	self.Scene:Play()
end

function Game:PostLogin(playerControl)
end

function Game:PostLogout(playerControl)
end
