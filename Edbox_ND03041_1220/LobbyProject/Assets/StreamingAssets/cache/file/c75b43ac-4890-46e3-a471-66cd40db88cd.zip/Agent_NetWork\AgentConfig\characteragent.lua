local json = require ("dkjson")
local BagMgr = require ("bagmgr")
local EquipMgr = require ("equipmentmgr")
local ItemType = require("itemtype")
--local ActorActControl = require("actoractcontrol")
--local CharacterMove = require ("charactermvoe")

require ("common")
local ShopItem = require("shopitem")
local itemType = require ("itemType")
local CONFIG = require("config")
local host = CONFIG.MMO_HTTP_SERVER_HOST
local port = CONFIG.MMO_HTTP_SERVER_PORT

agent CharacterAgent = 
{
	repnotify(Rep_PlayerId) playerId = 0,		   -- 角色ID（平台playerId）
	repnotify(Rep_Control) _playercontrol = {},
	repnotify(Rep_CharacterControl) _characterControl = {},
	nGameId = 0,			   					   -- 游戏ID
	repnotify(Rep_Name) playerName = "",		   -- 角色名称（平台名称）
	-- repnotify(Rep_LookFace) lookFace = {}       -- todo 拆分外观属性
	repnotify(Rep_Money) nMoney  = 1, 			   -- 角色金钱
	repnotify(Rep_IsEquip) nEquip = 0,             -- 是否装备 0 手上没有装备武器   1 手上装备武器
	repnotify(Rep_UseEquip) nItemType  = 0,        -- 武器栏武器ID   
	repnotify(Rep_UseBag) nBagType  = 0,	       -- 当前背包类型ID
	repnotify(Rep_BagCurLen) nBagCurLen = 0,       -- 背包当前剩余容量
	repnotify(Rep_GetAllBag) sBags = "",		   -- 所有背包
	repnotify(Rep_GetAllEquip) sEquips = "",	   -- 所有装备
	bagMgr = {},								   -- 背包管理器
	equipMgr = {},								   -- 装备管理器

	_mineData = {},										-- 矿数据缓存

	characterControl = {},						   -- 角色控制	
	characterMove = {},							   -- 角色移动

	--repnotify(Rep_pc) _playercontrol = {},		   -- 角色控制器

	-- 同步数据

	nMoveTimeStamp = 0,                            --客户端进行请求时候，记录下时间
	bMove = false,   
	nSpeed = 1,

	--repnotify(Rep_ActminingRep) nActmining = 0,		-- 同步挖矿动作 0停止 1开始

	repnotify(Rep_CurPos) vCurPos = Vector3(0,0,0),
	vTargetPos = Vector3(0,0,0),
	vDirection = Vector3(0,0,0),
	actionType = 0,

	--repnotify(Rep_MoveData) _moveData = {vCurPos = Vector3(0,0,0),vTargetPos = Vector3(0,0,0),vDirection = Vector3(0,0,0),actionType = 0},	   

	_bMining = false,							-- 是否在挖矿
	_audioMining = false,
	_audioAction = 0,							-- 动作声音

	-- 客户端属性
	_avatarCreateStep = 0,						-- 场景人物创建步骤
}

local AvatarStep =
{
	None = 0,
	Start = 1,
	Finish = 2,
}



function CharacterAgent:getPlayerId()
	return self.playerId;
end

function CharacterAgent:getMoney()
	return self.nMoney;
end

function CharacterAgent:setMoney(nVal)
	if(type(nVal) == "number") then
		print("nVal = " .. nVal)
		self.nMoney = nVal;
		print("after setMoney, = " .. self.nMoney)
	end
end

-- 角色加载时获取金钱
function CharacterAgent:getMoneyRes(nVal)
	print("nVal = " .. nVal)
	print(type(nVal))
	local obj, pos, err = json.decode (nVal, 1, nil)
	local value = {}
	if(type(obj.data.value) == "string")then
		local obj_, pos_, err_ = json.decode (obj.data.value, 1, nil)
		value = obj_
	end
	
	if value.money == nil then
		self.nMoney = 0;
	else
		self.nMoney = value.money;
	end
	print("after getMoneyRes, = " .. self.nMoney)
end

function CharacterAgent:setBagType(nType)
	self.nBagType = nType
end

function CharacterAgent:useEquip(tag, typeId)
	self.nEquip = tag;
	self.nItemType = typeId;
end

function CharacterAgent:getBagLen()
	return self.nBagCurLen
end

function CharacterAgent:setBagLen(nLen)
	self.nBagCurLen = nLen;
end

function CharacterAgent:Initialize()
	print('Character Init')
	self:SetReplicate(true)
	self:SetNetUpdate(100)
	self:SetRelevant(10000000)
	
	self:AddComponent('AgentSystemExtension.AgentComponent_Common')
	self:AddComponent('EbAgentCommon.AgentComponent_LuaMgr')


	if not self:HasAuthority() then
		self:AddComponent('EbAgentGame.AgentComponent_ClientCharacter')
		self:AddComponent('EbAgentGame.AgentComponent_CharacterState')
		self:AddComponent('EbAgentGame.AgentComponent_ScenePoint')
		self:AddComponent('ActionSystemCommon.AgentComponent_Audio')

		self:AddComponent('EbAgentGame.AgentComponent_MineState')
		self:AddComponent('EbAgentGame.AgentComponent_GameConsole')	

	else
		self:AddComponent('AC_Component_Character.AgentComponent_Character')
		self:AddComponent('AgentSystemExtension.AgentComponent_DataStore')
		self:AddComponent('AC_Component_Instance.AgentComponent_Instance')

	end
end

function CharacterAgent:OnStart()
	print("---------------------------- OnStart ------------------------------------") 

	if (not self:HasAuthority()) then
		
		if self:IsLocally() then
			print("Rep_character **********************************************")
			print("AgentClinet.gameId **********************************************" .. AgentClinet.gameId)
			print("AgentClinet.uid **********************************************" .. AgentClinet.uid)
			print(" AgentClinet.playerId **********************************************" .. AgentClinet.playerId)

			local clientParams = json.encode({gameId = AgentClinet.gameId, uid = AgentClinet.uid, playerId = AgentClinet.playerId })
			-- 初始化角色组件
			self:CharacterInit(host, port, clientParams)
			-- 注册副本广播方法
			self:SetIns("AC_Component_Instance.AgentComponent_Instance")
			-- 加载平台用户信息
			self:LoadCharacter()
			self:setPIdClient(AgentClinet.playerId)
			self:setGIdClient(AgentClinet.gameId)
			self:GetMoneyClient()
			self:LoadBagMgrClient()
			self:LoadEquipMgrClient()
			self:GetAllEquipClient()
			self:GetAllBagClient()

			self:SetAutonomous() --客户端自身的Pawn设置自主权
		end	
		
		AddPlayerAgent(self:GetOwner(), 'characteragent', self)

	else
		
		-- 动作控制器
		self._characterControl = CharacterControl:New(self)
		--self._characterControl._characterAgent = self
		self._characterControl:SetOwner(self)
	end
end


function CharacterAgent:Rep_CurPos()
	--print("~~~~~~~~~~~~~~CharacterAgent:Rep_CharacterCurPos")

	if self:HasAuthority() or self:IsLocally() then return end

end	


function CharacterAgent:CharacterMining(bMining)

	self._bMining = bMining;
	if self._bMining then
		if not self._audioMining then
			--self.Audio:PlayAudio("1d3047cd-ca57-41b9-9923-436a3dd47341" ,true);
		end	
		_audioMining = true;
	else
		self.Audio:StopAudio();
		_audioMining = false;
	end

	--print(" AgentClinet.CharacterMining **********************************************")
end

function CharacterAgent:getMineData()
	self:getSerMineData()
end

reliableserverfunction CharacterAgent:getSerMineData()

	local clientData = {}
	local tag = 1
	for key, value in pairs(MineCamps.oMineMap) do      
		if tag > 200 then --单个数据最大20480保证每次下去数据大小小于
			tag = 1
			self:getClientMineData(clientData)
			clientData = {}			
		end	
		
		table.insert(clientData, value.x)
		table.insert(clientData, value.y)
		table.insert(clientData, value.z)
		table.insert(clientData, value.nTypeId)
		table.insert(clientData, value.nLife)
		tag = tag + 1		
	end

	
	table.insert(clientData, -1)
	table.insert(clientData, -1)
	table.insert(clientData, -1)
	table.insert(clientData, -1)
	table.insert(clientData, -1)
	
	self:getClientMineData(clientData)

end 


-- 建立矿遮罩
function CharacterAgent:CreateMineMask()
	local range = Vector3(10, -1, 10)
	self.ClientCharacter:CreateSealingOre("f2b15eef-0b77-4de8-8bce-538677994c1a", range, "")
end	


clientfunction CharacterAgent:getClientMineData(mineData)
	
		local mineDataEnd = false

		local nLen  = table.getn(mineData);
		local  i = 1
		while i<nLen do
		if mineData[i+4] == -1 then
				mineDataEnd = true				
			else
			table.insert(self._mineData, mineData[i])
			table.insert(self._mineData, mineData[i+1])
			table.insert(self._mineData, mineData[i+2])
			table.insert(self._mineData, mineData[i+3])
			table.insert(self._mineData, mineData[i+4])
			--print("--------------------MiningSimulator CreateOreCamp ")
			end	
			
			i = i + 5
		end

		if mineDataEnd then
		--print("--------------------MiningSimulator CreateOreCamp ")
			self:CreateOreCamp()
		end	
	
end

function CharacterAgent:CreateOreCamp()
	-- 清理遮罩
	self.MineState:DestroySealingOre()
	MineCreateInfo.CreateCount = 0

	local nLen  = table.getn(self._mineData);
	MineCreateInfo.TotalCount = nLen / 5
	--self.MineState:SetCampsTotalNum(nLen)
	local  i = 1
	while i<nLen do		
		self.ClientCharacter:GetMineData(self._mineData[i], self._mineData[i+1], self._mineData[i+2], self._mineData[i+3], self._mineData[i+4], "OnCreateOreEnd")
		i = i + 5				
	end
end	

function CharacterAgent:OnCreateOreEnd(orePos)
	--print("--------------------MiningSimulator OnCreateOreEnd Count is "..self._mineCltCount)
	MineCreateInfo.CreateCount = MineCreateInfo.CreateCount + 1
	--self.MineState:SetCampsCreateNum(self._mineCltCount)

	if ( MineCreateInfo.CreateCount == MineCreateInfo.TotalCount) then
		self:FinishMineData()
	end	
	
end	

function CharacterAgent:FinishMineData()
	--print("---------------------------MiningSimulator FinishMineData")
	self.MineState:SetCampsCreated(true)
end

-- 设置角色playerId
function CharacterAgent:setPIdClient(playerId)
	print("setPId-Client....")
	self:setPIdServer(playerId)
end

reliableserverfunction CharacterAgent:setPIdServer(playerId)
	print("setPId Server....")
	self.playerId = playerId
	print("self.playerId...." .. self.playerId)
end

-- 设置游戏Id
function CharacterAgent:setGIdClient(nGameId)
	print("setGId-Client....")
	self:setGIdServer(nGameId)
end

reliableserverfunction CharacterAgent:setGIdServer(nGameId)
	print("setGId-Server....")
	self.nGameId = nGameId
	print("self.setGIdServer...." .. self.nGameId)
end

-- 加载当前背包
function CharacterAgent:LoadBagMgrClient()
	print("LoadBagMgr-Client....")
	self:LoadBagMgrServer()
end

reliableserverfunction CharacterAgent:LoadBagMgrServer()
	print("LoadBagMgr-Server....")
	self.bagMgr = BagMgr:new(self)
	self.bagMgr:initBag()
	self.sBags = self.bagMgr:getBags()
	print("********************load bagMgr OK***************************")
	-- self.bagMgr:addBag(3000000000801)
	
end

-- 加载当前装备
function CharacterAgent:LoadEquipMgrClient()
	print("LoadEquipMgr-Client....")
	self:LoadEquipMgrServer()
end

reliableserverfunction CharacterAgent:LoadEquipMgrServer()
	print("LoadEquipMgr-Server....")
	self.equipMgr = EquipMgr:new(self)
	self.equipMgr:initEquipment()
	self.sEquips = self.equipMgr:getEquipment()
	print("********************load EquipMgr OK***************************")
	print("self.equipMgr.nItemType = " .. self.nItemType)
	print("self.equipMgr.nEquip = " .. self.nEquip)
	-- self.equipMgr:addEquipment(2000100001001)
end

-- 加载所有背包
function CharacterAgent:GetAllBagClient()
	print("GetAllBag-Client....")
	self:GetAllBagServer()
end

reliableserverfunction CharacterAgent:GetAllBagServer()
	print("GetAllBag-Server....")
	self.sBags = self.bagMgr:getBags()
	print("********************GetAllBag OK***************************")
	print("self.sBags =>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " .. self.sBags)
end

-- 加载所有装备
function CharacterAgent:GetAllEquipClient()
	print("GetAllEquip-Client....")
	self:GetAllEquipServer()
end

reliableserverfunction CharacterAgent:GetAllEquipServer()
	print("GetAllEquip-Server....")
	self.sEquips = self.equipMgr:getEquipment()
	print("********************GetAllEquip OK***************************")
	print("self.sEquips =>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " .. self.sEquips)
end

reliableserverfunction CharacterAgent:CharacterInitS(host, port, clientParams)
	print("CharacterInitServer *******************************************")
	self.Character:Init(host, port, clientParams)
end

--初始化角色组件
function CharacterAgent:CharacterInit(host, port, clientParams)
	print("CharacterInit *******************************************")
	self:CharacterInitS(host, port, clientParams)
end

-- 注册副本广播
function CharacterAgent:SetIns(componentName)
	print("SetIns *******************************************")
	self:SetInsServer(componentName)
end

reliableserverfunction CharacterAgent:SetInsServer(componentName)
	print("SetInsServer *******************************************")
	self.Character:SetIns(componentName)
end

-- 加载角色信息
function CharacterAgent:LoadCharacter()
	print("LoadCharacter *******************************************")
	self:LoadFromServer()
end

reliableserverfunction CharacterAgent:LoadFromServer()
	print("LoadFromServer *******************************************")
	self.Character:LoadCharacterInfo()
end

-- 角色组件通过回调将数据返回
function CharacterAgent:OnLoadCharacterInfo(result)
	print("lua callback is doing *******************************************")
	print(result)
	local obj, pos, err = json.decode (result, 1, nil)
	print(type(obj.playerName))
	print(obj.playerName)
	self.playerName = obj.playerName
	print("self.playerName = " .. self.playerName)
	--self.lookFace = result.lookFace
end

-- 购买商店物品(客户端请求购买 -> 服务端serverfunction处理 -> 调用客户端clietnfunction告知客户端购买结果)
function CharacterAgent:BuyClient(shopItemId, itemNum)
	print("Buy-Client-------------------------" .. shopItemId, itemNum)
	self:BuyServer(tonumber(shopItemId), itemNum)
end

reliableserverfunction CharacterAgent:BuyServer(shopItemId, itemNum)
	local buyResult = {}
	print("Buy-Server-------------------------shopItemId = " .. shopItemId .. " itemNum = " .. itemNum)
	print(type(shopItemId))
	print(type(itemNum))

	if itemNum < 1 then
		print("---- itemNum = 0-----")
		buyResult.code = 1000 -- todo增加code配置文件
		buyResult.buyResult = "itemNum = 0"
		self:SendBuyResult(json.encode(buyResult))
		return
	end
	-- 还要判断背包容量是否OK
	

	local tItem = ShopItem[shopItemId] --试一下取不到是不是等于nil
	if tItem == nil then
		buyResult.code = 1000 -- todo增加enumcode配置文件
		print("---- no exist this item -----")
		buyResult.code = 1001 -- todo增加code配置文件
		buyResult.buyResult = "no exist this item"
		self:SendBuyResult(json.encode(buyResult))
		return
	end
	print("----------------------------")
	local nItemPrice = tItem.price
	local nItemTypeId = tItem.itemTypeId
	if(type(nItemPrice) == "string") then
		nItemPrice = tonumber(nItemPrice)
	end
	if(type(nItemTypeId) == "string") then
		nItemTypeId = tonumber(nItemTypeId)
	end
	local nItemType = ItemType[nItemTypeId].type

	-- 判断角色是否已经拥有该物品了

	local canBug = false
	if(nItemType == 4) then
		if(self.bagMgr.bags[nItemTypeId] == nil) then
			canBug = true
		end
	elseif(nItemType == 3) then
 		if(self.equipMgr.equipments[nItemTypeId] == nil) then
			canBug = true
		end
	end
	
	if(canBug) then
		-- 判断角色当前金钱是否足够
		if nItemPrice <= self.nMoney then
			-- 扣钱入库
			local money = self.nMoney - nItemPrice
			local sendData = {}
			sendData.storeKey = self.nGameId .. "." .. self:getPlayerId() .. ".money" 
			local value = {}
			value.money = money
			sendData.value = json.encode(value)
			sendData.apiName = "set"
			sendData.nItemPrice = nItemPrice
			sendData.nItemType = nItemType
			sendData.nItemTypeId = nItemTypeId
			sendData = json.encode(sendData)
			self.DataStore:DataStoreOperation(host, port, sendData, "setMoneyToDB")
			return    
		else
			print("money is not enough, money = " .. self.nMoney .. " itemPrice = " .. nItemPrice)
			buyResult.code = 1002 -- todo增加code配置文件
			buyResult.buyResult = "money is not enough"
			self:SendBuyResult(json.encode(buyResult))
			return
		end
	else
		print("Already owned ------------------------------------nItemTypeId: " .. nItemTypeId )
		buyResult.code = 1003 -- todo增加code配置文件
		buyResult.buyResult = "Already owned"
		self:SendBuyResult(json.encode(buyResult))
		return
	end
end

function CharacterAgent:setMoneyToDB(list)
    local list = json.decode(list)
    local code = list.code
	local data = list.data
	local buyResult = {}
	if((type(code) == "number" and code == 200) or (type(code) == "string" and tonumber(code) == 200)) then
		self.nMoney = self.nMoney - data.nItemPrice
		print("after buy something, money = " .. self.nMoney)
		-- 判断是购买装备还是背包 3 武器 4 背包
		if data.nItemType == 4 then
			self.bagMgr:addBag(data.nItemTypeId) -- 添加背包添加背包
		end
		if data.nItemType == 3 then
			self.equipMgr:addEquipment(self.playerId, data.nItemTypeId) -- 添加装备
		end
		buyResult.code = 200 -- todo增加code配置文件
		buyResult.buyResult = "success"
		self:SendBuyResult(json.encode(buyResult))
	else
		buyResult.code = 1004 -- todo增加code配置文件
		buyResult.buyResult = "DB error"
		self:SendBuyResult(json.encode(buyResult))
		return
	end
end

-- 购买商品结果
clientfunction CharacterAgent:SendBuyResult(buyResult)
	print("Buy result = "..buyResult)
end

-- 通知客户端角色ID已获取
function CharacterAgent:Rep_PlayerId()
	print("PlayerID_Notify *******************************************" .. self.playerId)
	self.ClientCharacter:GetGamePlayer(self.playerId) -- 新增通知

	if self.playerId ~= 0 then
		self:CreateSceneCharacter()
	end	
end

-- 通知客户端角色控制器已获取
function CharacterAgent:Rep_Control()

	--if self._avatarCreateStep == AvatarStep.Finish then
		print("_PlayerControl *******************************************" )
		--self._playercontrol:InitControl()
	--end	
	end

function CharacterAgent:Rep_CharacterControl()
	if self._characterControl ~= {} then
		--self._characterControl:Init()
end	
end	

-- 通知客户端角色名已获取
function CharacterAgent:Rep_Name()
	print("PlayerName_Notify *******************************************" .. self.playerName)
	self.ClientCharacter:NameChanged(self.playerName) 
end

-- 通知客户端金钱值改变
function CharacterAgent:Rep_Money()
	if (not self:HasAuthority()) and self:IsLocally() then
		print("Money_Change *******************************************" .. self.nMoney)
		self.ClientCharacter:MoneyChanged(self.nMoney) 
	end
end

-- 通知客户端角色装卸装备
function CharacterAgent:Rep_IsEquip()
	print("Rep_isEquip *******************************************" .. self.nEquip)
	self.ClientCharacter:IsEquipChanged(self.nEquip) -- 新增通知
end

-- 通知客户端背包外观改变（使用背包）
function CharacterAgent:Rep_UseBag()
	print("Bag_Change *******************************************" .. self.nBagType)
	self.ClientCharacter:BagChanged(self.nBagType) 
end

-- 通知客户端装备外观改变（使用装备）
function CharacterAgent:Rep_UseEquip()
	print("Equip_Change *******************************************" .. self.nItemType)
	self.ClientCharacter:EquipChanged(self.nItemType) 
end

-- 通知客户端背包剩余容量
function CharacterAgent:Rep_BagCurLen()

	if (not self:HasAuthority()) and self:IsLocally() then
		print("BagCurLen_Change *******************************************" .. self.nBagCurLen)
		self.ClientCharacter:BagCurLenChanged(self.nBagCurLen)  -- 新增通知
	end
end

-- 通知客户端获取所有背包
function CharacterAgent:Rep_GetAllBag()
	print("Rep_GetAllBag *******************************************"..self.sBags)
	self.ClientCharacter:GetAllBag(self.sBags)  -- 新增通知
end

-- 通知客户端获取所有武器
function CharacterAgent:Rep_GetAllEquip()
	print("Rep_GetAllEquip *******************************************" .. self.sEquips)
	self.ClientCharacter:GetAllEquip(self.sEquips)  -- 新增通知
end

-- 从DataStore获取角色金钱
function CharacterAgent:GetMoneyClient()
	print("getMoneyClient is invoking here....")
	self:GetMoneyServer()
end

reliableserverfunction CharacterAgent:GetMoneyServer()
	print("getMoneyServer is invoking here....")
	print("money = " .. self.nMoney)

    local storeKey =  self.nGameId .. "." .. self.playerId .. ".money" 
	print("storeKey = " .. storeKey)
    local sendData = {}
    sendData.storeKey = storeKey
    sendData.apiName = "get"
    sendData = json.encode(sendData)
	print("setData= " .. sendData)
    self.DataStore:DataStoreOperation(host, port, sendData, "getMoneyRes") --调用DataStore组件
end

clientfunction CharacterAgent:leveMineCamps()
	--在矿区 ，回地面
	--print("leveMineCamps    1111111111111111111111111111111111111111111111111111111111  " )
	if (not self:HasAuthority()) then
		self.ClientCharacter:LeaveMineCamps();
	end
end

-- 角色退出游戏时调用
function CharacterAgent:OnDestroy()
	print("Character OnDestroy....")

	if (not self:HasAuthority()) then
		self.CharacterState:DestoryCharacter();
		self.ClientCharacter:DestoryOb();
	end
end

--挖矿动作
serverfunction CharacterAgent:Mineral(pos)
	print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>begin Mineral>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", self.nItemType, self.nBagType)
	print("************************************************self.nBagCurLen" .. self.nBagCurLen)
	print("************************************************itemType[self.nBagType].storage" .. itemType[self.nBagType].storage)
	if(pos.x == nil or pos.y == nil or pos.z == nil)then
		print("pos is error")
		return
	end
	local posArr = {pos.x,pos.y,pos.z}
	--self.nItemType = 2000100000701	
	local item = ItemType[self.nItemType];
	if(Prejudgement(item) == false)then
		print("Prejudgement error")
		return
	end
	local mineData = MineCamps:getMineCell(posArr)
	if mineData == nil or mineData== false then
		return
	end
	local curWeight = mineData.nLife
	local mine = ItemType[mineData.nTypeId]
	if(PrejudgementMine(mine) == false)then
		print("PrejudgementMine error ")
		return
	end
	-- 判断装备是否支持挖
	if(isRequire(mine, item) == false) then
		print("mine/equipe > 37")
		return -1
	end
	-- 判断矿和人物距离 minePos单位坐标
--	local disx = math.pow(self.vCurPos.x-minePos.x,2)
--	local disy = math.pow(self.vCurPos.y-minePos.y,2)
--	local disz = math.pow(self.vCurPos.z-minePos.z,2)
--	local disNum = math.sqrt(disx + disy + disz)
--	if (disNum/4 > item.range)then
--		print("mineral distance no enough")
--		return
--	end
	--printTable(pos);
	local attack = ItemType[self.nBagType].storage - self:getBagLen()
	if item.attack < attack then
		attack = item.attack
	end
	if (attack <1) then
		--print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>attack value error>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
		return
	end
	
	local res = MineCamps:mineral(posArr, attack)
	local dataArr = {}
	dataArr[res.nTypeId] =  res.nLife
	print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>begin putBag>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	self.bagMgr:putBag(dataArr)
	printTable(dataArr);
end


function CharacterAgent:OnUpdate(DeltaTime)
	
	if self:HasAuthority() then
		--移动的数据 定时 进行判断处理
		self:processMove()
	else
		
		if (self.actionType == 3) then
			if (self._audioAction ~= self.actionType) then
				self.Audio:PlayAudio("0619b47d-e435-4e2e-83ea-2f141e063668", true)
				self._audioAction = self.actionType
			end
				
		-- 挖矿	
		elseif (self.actionType == 9) then
			if (self._audioAction ~= self.actionType) then
				self.Audio:PlayAudio("0981d85f-377b-468d-8260-1ad5801dead0", true);
				self._audioAction = self.actionType;
			end	
		elseif (self._audioAction ~= self.actionType) then
			self.Audio:StopAudio();
			self._audioAction = self.actionType;

		end		
	end
end

-- -------------------背包------------------------->
-- 加载背包
function CharacterAgent:getBagRes(list)
	self.bagMgr:getBagRes(list)
end
-- 加载物品
function CharacterAgent:getItemsRes(list)
	self.bagMgr:getItemsRes(list)
end

function CharacterAgent:addItemRes(list)
	self.bagMgr:addItemRes(list)
end

function CharacterAgent:addBagsRes(list)
	self.bagMgr:addBagsRes(list)
end

function CharacterAgent:exchangeRes(list)
	self.bagMgr:exchangeRes(list)
end

function CharacterAgent:delItemsRes(list)
	self.bagMgr:delItemsRes(list)
end

function CharacterAgent:bgMsetMoneyRes(list)
	self.bagMgr:bgMsetMoneyRes(list)
end

-- client
function CharacterAgent:sellItemClient()
	local type = "mine"
	self:sellItemServer(type)
end

reliableserverfunction CharacterAgent:sellItemServer(type)
	if(type == "mine") then
		if(self.nBagCurLen > 0) then
			local res = self.bagMgr:sellItem(type)
			if(res)then
				self:SendResult(200, "sellItem success")
			else
				self:SendResult(500, "sellItem fail")
			end
		else
			self:SendResult(2001, "have no items")
		end
	end
end

-- client
function CharacterAgent:exchangeBag(bagId)
	self:exchBagServer(bagId)
end

reliableserverfunction CharacterAgent:exchBagServer(bagId)
	if(type(bagId) == "string") then
		bagId = tonumber(bagId)
	end
	if(self.bagMgr.bags[bagId] ~= nil) then
		local res = self.bagMgr:exchange(bagId)
		if(res)then
			self:exchBagRespond(200, "exchBagServer success")
		else
			self:exchBagRespond(500, "exchBagServer fail")
		end
	else
		self:exchBagRespond(2002, "have no bag ----------------------bagId: " .. bagId)
	end
end

clientfunction CharacterAgent:exchBagRespond(code, describe)
	local storeUI=self.LuaMgr:GetLua('ShopStoreUI')
	storeUI:ExChangeBagReturn(code)
end	
-- <--------------------------------------------------

clientfunction CharacterAgent:SendResult(code, describe)
	local result = {}
	result.code = code
	result.result = describe
	print("Server result ================================= : ".. json.encode(result))
end		

-- -------------------装备---------------------------->
-- 加载装备
function CharacterAgent:getEquipmentRes(list)
	self.equipMgr:getEquipmentRes(list)
end

function CharacterAgent:addEquipRes(list)
	self.equipMgr:addEquipRes(list)
end

function CharacterAgent:chgNewEquipRes(list)
	self.equipMgr:chgNewEquipRes(list)
end

function CharacterAgent:activeEuipRes(list)
	self.equipMgr:activeEuipRes(list)
end

-- client
function CharacterAgent:exchangeEquip(equipmentId)
	self:exchEquip(equipmentId)
end

reliableserverfunction CharacterAgent:exchEquip(equipmentId)
	print("--------------------------------------------------type(equipmentId):".. type(equipmentId))
	if(type(equipmentId) == "string")then
		equipmentId = tonumber(equipmentId)
	end
	if(self.equipMgr.equipments[equipmentId] ~= nil) then
		local res = self.equipMgr:changeEquip(self.playerId, equipmentId)
		if(res) then
			self:exchEquipRespond(200, "changeEquip success")
		else  
			self:exchEquipRespond(500, "changeEquip fail")
		end
	else
		self:exchEquipRespond(2003, "have no equipment,  -----------------------------equipmentId: " .. equipmentId)
	end
end

clientfunction CharacterAgent:exchEquipRespond(code, describe)
	local storeUI=self.LuaMgr:GetLua('ShopStoreUI')
	storeUI:ExChangeEquipReturn(code)
end	

function CharacterAgent:OnEquipClick()
	print("--------------------------------------------------OnEquipClick:")
	self:ActiveEquip(self.nItemType, 1);
end

-- client
function CharacterAgent:ActiveEquip(id, tag)
	if(type(id) == "string") then
		id = tonumber(id)
	end
	local itemTypeId = id
	self:activeEquipS(itemTypeId, tag)
end

reliableserverfunction CharacterAgent:activeEquipS(itemTypeId, tag)
	if(self.equipMgr.equipmentSet[tag] ~= nil) then
		local res = self.equipMgr:activeEuipment(itemTypeId, tag)
		if(res) then
			self:SendResult(200, "activeEuipment success")
		else  
			self:SendResult(500, "activeEuipment fail")
		end
	else
		self:SendResult(2003, "this is bug----------------------equipMgr.equipmentSet is nil")
	end
end

-- <----------------------------------------------------

function CharacterAgent:OnBeginMining( pos )
	
end

function  CharacterAgent:OnEndMining( pos )
	self:Mineral(pos)
end

---------------------------------- 同步玩家位置 -----------------------------------
function CharacterAgent:Rep_MoveData()
	print("~~~~~~~~~~~~CharacterAgent:Rep_MoveData")
end

--客户端调用停止移动
serverfunction CharacterAgent:SrvMoveStop(vTargetPos, actionType, nTimeStamp)	
	self:SrvStop(vTargetPos, actionType, nTimeStamp)
end

--服务端处理移动数据
reliableserverfunction CharacterAgent:SrvStop(vTargetPos, actionType, nTimeStamp)

	--float类型做精度处理
	local nOldTargetPosX = math.floor(self.vTargetPos.x*100+0.5)*0.01
	local nOldTargetPosY = math.floor(self.vTargetPos.y*100+0.5)*0.01
	local nOldTargetPosZ = math.floor(self.vTargetPos.z*100+0.5)*0.01

	local nNewTargetPosX = math.floor(vTargetPos.x*100+0.5)*0.01
	local nNewTargetPosY = math.floor(vTargetPos.y*100+0.5)*0.01
	local nNewTargetPosZ = math.floor(vTargetPos.z*100+0.5)*0.01

	--目标位置与之前的目标位置相等时，不处理
	if(nOldTargetPosX == nNewTargetPosX and nOldTargetPosY == nNewTargetPosY and nOldTargetPosZ == nNewTargetPosZ) then
		return
	end

	--进行移动处理
	self.bMove = false	
	self.vDirection = Vector3(0,0,0)
	self.actionType = actionType
	self.vTargetPos = vTargetPos;
	self.vCurPos = vTargetPos;
	self.nMoveTimeStamp = self.Common:GetTimeStamp()


	self:BroadCastStopData(self.vCurPos, self.vTargetPos, self.vDirection,self.actionType, nTimeStamp);
	--self.moveState = {curPosX = fromPosX, curPosY = fromPosY, curPosZ = fromPosZ, targetX = toPosX, targetY = toPosY, targetZ = toPosZ, dirX = vDirection.x, dirY = vDirection.y, dirZ = vDirection.z, nTimeStamp = self.nMoveTimeStamp };
end


--服务端处理移动数据
reliableserverfunction CharacterAgent:SrvMove(vCurPos, vTargetPos, vDirection, actionType, nTimeStamp)

	--float类型做精度处理
	local nOldTargetPosX = math.floor(self.vTargetPos.x*100+0.5)*0.01
	local nOldTargetPosY = math.floor(self.vTargetPos.y*100+0.5)*0.01
	local nOldTargetPosZ = math.floor(self.vTargetPos.z*100+0.5)*0.01

	local nNewTargetPosX = math.floor(vTargetPos.x*100+0.5)*0.01
	local nNewTargetPosY = math.floor(vTargetPos.y*100+0.5)*0.01
	local nNewTargetPosZ = math.floor(vTargetPos.z*100+0.5)*0.01

	--目标位置与之前的目标位置相等时，不处理
	if (actionType == self.actionType) and (nOldTargetPosX == nNewTargetPosX and nOldTargetPosY == nNewTargetPosY and nOldTargetPosZ == nNewTargetPosZ) then
		return
	end


	local nCurPosX = math.floor(self.vCurPos.x*100+0.5)*0.01
	local nCurPosY = math.floor(self.vCurPos.y*100+0.5)*0.01
	local nCurPosZ = math.floor(self.vCurPos.z*100+0.5)*0.01

	--目标位置与角色当前位置相等且动作相同时，不处理
	if (actionType == self.actionType) and (nCurPosX == nNewTargetPosX and nCurPosY == nNewTargetPosY and nCurPosZ == nNewTargetPosZ) then
		return
	end

	--进行移动处理
	self.bMove = true	
	self.vDirection = vDirection
	self.actionType = actionType
	self.vCurPos = Vector3(vCurPos.x, vCurPos.y, vCurPos.z)
	self.vTargetPos = vTargetPos
	self.nMoveTimeStamp = self.Common:GetTimeStamp()

	self:BroadCastMoveData(vCurPos, vTargetPos, vDirection, actionType, nTimeStamp);
	--self.moveState = {curPosX = fromPosX, curPosY = fromPosY, curPosZ = fromPosZ, targetX = toPosX, targetY = toPosY, targetZ = toPosZ, dirX = vDirection.x, dirY = vDirection.y, dirZ = vDirection.z, nTimeStamp = self.nMoveTimeStamp };
end


broadcastfunction CharacterAgent:BroadCastMoveData(vCurPos, vTarget, vDir, actionType, nTime)
	self:UpdateMoveData(vCurPos, vTarget, vDir, actionType, nTime);
end

broadcastfunction CharacterAgent:BroadCastStopData(vCurPos, vTarget, vDir, actionType, nTime)
	self:UpdateStopData(vCurPos, vTarget, vDir, actionType, nTime);
end


function CharacterAgent:UpdateMoveData(vCurPos, vTarget, vDir, actionType, nTime)
	if  self:IsLocally() then return end

	--print("!!!!!!!!!!!!CharacterAgent:UpdateMoveData");
	--self.CharacterState:OnRep_ReplicateMove(vCurPos, vTarget, vDir,actionType, nTime)
	if self.CharacterSync ~= nil then
		self.CharacterSync:MoveTo(vCurPos, vTarget, vDir, nTime)
	end	
end

function CharacterAgent:UpdateStopData(vCurPos, vTarget, vDir, actionType, nTime)
	if  self:IsLocally() then return end

	--print("#####################CharacterAgent:UpdateStopData");
	--self.CharacterState:OnRep_ReplicateStop(vCurPos, vTarget, vDir, actionType, nTime)
	if self.CharacterSync ~= nil then
		self.CharacterSync:MoveStop(vTarget, nTime)
	end
end	


--服务端对移动的数据 定时 进行判断处理
function CharacterAgent:processMove()
	if (self.bMove == false) then --角色没有移动，不需要处理
	end

	local nCurTimeStamp = self.Common:GetTimeStamp()
	local nDiffTime = nCurTimeStamp - self.nMoveTimeStamp --时间间隔
	local nMoveDistance = nDiffTime * self.nSpeed  --移动距离
	local nMaxDistance = getDis(self.vCurPos, self.vTargetPos) --当前位置与目标位置距离
	self.nMoveTimeStamp = self.Common:GetTimeStamp() --processMove定时运行，更新下时间

	if(nMoveDistance >= nMaxDistance) then
		self.bMove = fasle
		self.vCurPos = self.vTargetPos
		return
	end
 
    --processMove定时运行，bMove = true,下一次会进来，（隔一段时间移动一小段，更新当前位置）
    local nDistance = nMaxDistance - nMoveDistance;
	--移动一段距离后，移动后的位置 设置成 当前位置

	--self.vCurPos = getPos(self.vCurPos, self.vTargetPos, nDistance)
end

-- 获取角色实时位置
function CharacterAgent:getCurPos()
    return self.vCurPos;
end

-- 角色是否装备武器
function CharacterAgent:IsEquip()
	return self.nEquip > 0
end	


-- 创建场景人物角色
function CharacterAgent:CreateSceneCharacter()

	if self._avatarCreateStep ~= AvatarStep.None  then
		return 
	end
	
	self.CharacterState:CreateCharacter(self.playerId, self.vCurPos, "893e7bc3-cd71-4899-acc5-a0fcd0cc9838")
	self._avatarCreateStep = AvatarStep.Start

end


-- 创建场景人物角色成功
function CharacterAgent:OnFinishCharacter()
	
	-- 同步组件
	self:AddComponent('EbAgentGame.AgentComponent_CharacterSync')


	self.ClientCharacter:RefreshPlugin();

	self._avatarCreateStep = AvatarStep.Finish

	self._characterControl:Init(self.playerId)

	self.CharacterSync:Init()

	self.CharacterSync:SetSyncCallBack('CharacterMove', 'CharacterStop', 'CharacterFlash')

	if (self:IsLocally()) then

		-- GM 界面
		self.GameConsole:InitData('perfab/CanvasConsole', 'PMSend')	
		-- 设置初始位置

		local randomPos = self.ClientCharacter:GetBornPosition()
		local pos = Vector3(randomPos.x, randomPos.y, randomPos.z)
		self.CharacterSync:FlashMoveTo(pos)
	end
end

function CharacterAgent:GetAvatarControl()
	return self._characterControl
end


function CharacterAgent:PMSend(cmdData)
	self:PMCmd(cmdData)
	--self.vCurPos = Vector3(0,0,0);

	--self:SrvFlashMove(self.vCurPos);
end

-- 服务端PM命令
serverfunction CharacterAgent:PMCmd(cmdData)
	if(string.match(string.lower(cmdData), "money") ~= nil) then
		local number = string.gsub(string.lower(cmdData),"addmoney","");
		local money = self.nMoney + number
		if(type(money) == "number" and money<=1000000000) then
			local storeKey =  self.nGameId .. "." .. self.playerId .. ".money"
			local sendData = {}
			sendData.storeKey = storeKey
			sendData.apiName = "set"
			local value = {}
			value.money = money
			sendData.value = json.encode(value)
			sendData = json.encode(sendData)
			self.DataStore:DataStoreOperation(host, port, sendData, "getMoneyRes")
		end
	end
end

-- 同步人物位置
function CharacterAgent:CharacterMove(fromPosX, fromPosY, fromPosZ, toPosX, toPosY, toPosZ, dirX, dirY, dirZ, nTimeStamp)

	if self:IsLocally() then
	self.vCurPos = Vector3(fromPosX, fromPosY, fromPosZ);
	self.vDirection = Vector3(dirX, dirY, dirZ);
	self.vTargetPos = Vector3(toPosX, toPosY, toPosZ);
		self.actionType = 0
	self.nMoveTimeStamp = nTimeStamp
	--print("************************CharacterAgent:CharacterMove ");

	--self.ClientCharacter:Move(self.vCurPos, self.vTargetPos, self.vDirection)
	self:SrvMove(self.vCurPos, self.vTargetPos, self.vDirection, self.actionType, self.nMoveTimeStamp);
	
	else
		self._characterControl:AvatarMoveTo()
end
end

function CharacterAgent:CharacterStop(vCurPosX, vCurPosY, vCurPosZ, nTimeStamp)
	--local sMoveData = json.encode({playerId = self.playerId, vCurPos = fromPos,vTargetPos = toPos, vDirection = dir ,actionType = action});
	--print(sMoveData);

	if self:IsLocally() then 
	--print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CharacterStop");
	self.vTargetPos = Vector3(vCurPosX,vCurPosY,vCurPosZ);
		self.actionType = 0
	self.nMoveTimeStamp = nTimeStamp
	--self.vDirection = Vector3(vDirectionX,vDirectionY,vDirectionZ);
	self:SrvMoveStop(self.vTargetPos, self.actionType, self.nMoveTimeStamp);
	else
		self._characterControl:AvatarMoveStop()
	end

	--self.Audio:StopAudio()
end


-- 瞬移
function CharacterAgent:CharacterFlash(vCurPosX, vCurPosY, vCurPosZ)
	self.vTargetPos = Vector3(vCurPosX,vCurPosY,vCurPosZ);
	self.vCurPos = Vector3(vCurPosX,vCurPosY,vCurPosZ);

	self:SrvFlashMove(self.vTargetPos);
end

-- 同步玩家动作
function CharacterAgent:toSurface()
	local surfacePoint = self.ScenePoint:GetPoint("ToSurface")

	self.CharacterSync:FlashMoveTo(surfacePoint)

	--self.ClientCharacter:ToPosition(surfacePoint)
	--self.actionType = action;
	
	--self.ClientCharacter:Equip(47)
	--self.ClientCharacter:UnEquip()
	--self.ClientCharacter:EquipBag(48)
end

serverfunction CharacterAgent:SrvFlashMove(vTargetPos)
	self:BroadCastFlashMove(vTargetPos)
end

broadcastfunction CharacterAgent:BroadCastFlashMove(vTargetPos)
	self.vTargetPos = vTargetPos;
	self.vCurPos = vTargetPos;
	self:UpCltFlashMove(self.vTargetPos, self.vDirection, self.actionType);
end

function CharacterAgent:UpCltFlashMove(vTargetPos, vDirection, actionType)

	if not self:IsLocally() then

		self.vTargetPos = vTargetPos;
		self.vCurPos = vTargetPos;
		self.actionType = actionType;
		self.vDirection = vDirection;
		
		--self.CharacterState:OnRep_ReplicatePos(vTargetPos, vDirection, actionType, 0);
	end	
end	
